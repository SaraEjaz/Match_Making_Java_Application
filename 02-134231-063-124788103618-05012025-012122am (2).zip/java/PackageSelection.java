import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.time.LocalDate;

public class PackageSelection extends JFrame {
    int candidateId;
    String username;

    public PackageSelection(int candidateId,String username) {
        this.candidateId = candidateId;
this.username=username;
        // Set the JFrame properties
        setTitle("Package Selection");
        setSize(800, 300);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout()); // Changed to BorderLayout for better placement of buttons and panels

        // Create panels for packages with dynamic information
        JPanel packagePanel = new JPanel(new GridLayout(1, 2, 10, 10));
        packagePanel.add(createPackagePanel("Gold", 10000.00, 45, 2));
        packagePanel.add(createPackagePanel("Personalized", 50000.00, 60, 3));
        
        // Add the package selection panel
        add(packagePanel, BorderLayout.CENTER);

        // Create a back button
        JButton backButton = new JButton("Back");
        backButton.setBackground(Color.WHITE);
        backButton.setForeground(new Color(128, 0, 0));
        backButton.setFont(new Font("Arial", Font.BOLD, 14));
        backButton.addActionListener(e -> {
            // Assuming you have a WelcomePage class that represents the welcome screen
            new WelcomePage(username,  candidateId); // Initialize the WelcomePage frame
            dispose(); // Close the current frame (PackageSelection)
        });

        // Add back button at the bottom
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(backButton);
        add(buttonPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private JPanel createPackagePanel(String packageName, double price, int duration, int packageId) {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(BorderFactory.createLineBorder(Color.BLACK, 2)); // Border for each box
        panel.setBackground(new Color(128, 0, 0)); // Maroon color

        JLabel label = new JLabel(packageName + " PACKAGE", JLabel.CENTER);
        label.setAlignmentX(Component.CENTER_ALIGNMENT);
        label.setForeground(Color.WHITE);
        label.setFont(new Font("Arial", Font.BOLD, 16));

        JLabel priceLabel = new JLabel("Price: PKR " + price, JLabel.CENTER);
        priceLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        priceLabel.setForeground(Color.WHITE);
        priceLabel.setFont(new Font("Arial", Font.PLAIN, 14));

        JLabel durationLabel = new JLabel("Duration: " + duration + " days", JLabel.CENTER);
        durationLabel.setAlignmentX(Component.CENTER_ALIGNMENT);
        durationLabel.setForeground(Color.WHITE);
        durationLabel.setFont(new Font("Arial", Font.PLAIN, 14));

        JButton button = new JButton("BUY NOW");
        button.setAlignmentX(Component.CENTER_ALIGNMENT);
        button.setBackground(Color.WHITE);
        button.setForeground(new Color(128, 0, 0));
        button.setFont(new Font("Arial", Font.BOLD, 14));
        button.addActionListener(e -> handlePackageSelection(packageId, duration));

        panel.add(Box.createVerticalGlue());
        panel.add(label);
        panel.add(priceLabel);
        panel.add(durationLabel);
        panel.add(Box.createVerticalStrut(10));
        panel.add(button);
        panel.add(Box.createVerticalGlue());

        return panel;
    }

    private void handlePackageSelection(int packageId, int duration) {
        LocalDate startDate = LocalDate.now();
        LocalDate endDate = startDate.plusDays(duration);

        String insertQuery;

        try (Connection conn = DatabaseConnection.connect()) {
            if (packageId == 2) { // Gold Package
                String updateQuery = "UPDATE userPackages SET packageID = ?, startdate = ?, enddate = ?, Consultantid = NULL " +
                                     "WHERE candidateid = ? AND packageID != 2";
                try (PreparedStatement stmt = conn.prepareStatement(updateQuery)) {
                    stmt.setInt(1, packageId);
                    stmt.setDate(2, Date.valueOf(startDate));
                    stmt.setDate(3, Date.valueOf(endDate));
                    stmt.setInt(4, candidateId);
                    int rowsUpdated = stmt.executeUpdate();

                    if (rowsUpdated > 0) {
                        JOptionPane.showMessageDialog(this, "Gold Package updated successfully!");
                    } else {
                        JOptionPane.showMessageDialog(this, "No existing package found to update for the candidate.");
                    }
                }
            } else if (packageId == 3) { // Personalized Package
                String adminQuery = "SELECT Admin_ID FROM Admin";
                try (Statement adminStmt = conn.createStatement();
                     ResultSet rs = adminStmt.executeQuery(adminQuery)) {

                    java.util.List<Integer> adminIds = new java.util.ArrayList<>();
                    while (rs.next()) {
                        adminIds.add(rs.getInt("Admin_ID"));
                    }

                    if (!adminIds.isEmpty()) {
                        int consultantId = adminIds.get(new java.util.Random().nextInt(adminIds.size()));
                        insertQuery = "INSERT INTO userPackages (packageID, startdate, enddate, candidateid, Consultantid) " +
                                "VALUES (?, ?, ?, ?, ?)";
                        try (PreparedStatement stmt = conn.prepareStatement(insertQuery)) {
                            stmt.setInt(1, packageId);
                            stmt.setDate(2, Date.valueOf(startDate));
                            stmt.setDate(3, Date.valueOf(endDate));
                            stmt.setInt(4, candidateId);
                            stmt.setInt(5, consultantId);
                            stmt.executeUpdate();
                            JOptionPane.showMessageDialog(this, "Personalized Package purchased successfully!");
                        }
                    } else {
                        JOptionPane.showMessageDialog(this, "No admin available for the Personalized Package.");
                    }
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            ex.printStackTrace();
        }
    }

    public static void main(String[] args) {
        
    }
}
