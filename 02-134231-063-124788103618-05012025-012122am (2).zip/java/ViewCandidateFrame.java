import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import javax.swing.border.TitledBorder;


public class ViewCandidateFrame extends JFrame {
    private int UserID;

    public ViewCandidateFrame(int UserID) {
        this.UserID= UserID;
        setTitle("Candidate Details");
        setSize(1200, 800); // Adjusted size to accommodate all details
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        initUI();
        fetchCandidateData();
    }
    

  private void fetchCandidateData() {
    try (Connection connection = DatabaseConnection.connect()) {
        if (connection != null) {
            // SQL query to fetch all details based on UserID
            String query = "SELECT " +
                "U.FirstName, U.LastName, U.Email, U.Phone, U.City, U.Country, U.MaritalStatus, U.DateOfBirth, " +
                "U.MotherTongue, U.Caste, U.Gender, U.UserName, U.DateJoined, C.CandidateID, " +
                "Q.QualificationID, Q.University, Q.MajorCourse, Q.Profession AS QualificationProfession, " +
                "Job.JobName, " +  // Fetching JobName from Job table
                "J.JobID, J.MonthlyIncome AS JobMonthlyIncome, J.FuturePlan AS JobFuturePlan, " +
                "I.ImageID, I.PrivacyStatus AS ImagePrivacyStatus, " +
                "A.AppearanceID, A.Disability AS AppearanceDisability, A.Height AS AppearanceHeight, " +
                "A.Smoke AS AppearanceSmoke, A.Complexion AS AppearanceComplexion, A.HairColor AS AppearanceHairColor, " +
                "A.Weight AS AppearanceWeight, A.Build AS AppearanceBuild, A.EyeColor AS AppearanceEyeColor, " +
                "R.UserReligionID, R.ReligionID, Religion.ReligionType, " +  // Fetching ReligionType from Religion table
                "R.KeepHalal AS ReligionKeepHalal, R.HijabPreference AS ReligionHijabPreference, " +
                "R.BeardPreference AS ReligionBeardPreference, R.ConvertedReligion AS ReligionConvertedReligion, " +
                "R.Sect AS ReligionSect, R.PerformSalah AS ReligionPerformSalah, " +
                "E.ExpID, E.AgeFrom AS ExpectationsAgeFrom, E.AgeTo AS ExpectationsAgeTo, " +
                "E.Gender AS ExpectationsGender, E.Country AS ExpectationsCountry, " +
                "E.MotherTongue AS ExpectationsMotherTongue, E.Sect AS ExpectationsSect, " +
                "E.Profession AS ExpectationsProfession, E.MaritalStatus AS ExpectationsMaritalStatus, " +
                "E.Height AS ExpectationsHeight, E.Caste AS ExpectationsCaste, E.Religion AS ExpectationsReligion, " +
                "E.MonthlyIncome AS ExpectationsMonthlyIncome, E.Build AS ExpectationsBuild, E.Disability AS ExpectationsDisability " +
                "FROM [User] U " +
                "JOIN Candidate C ON U.UserID = C.UserID " +
                "LEFT JOIN UserQualification Q ON C.UserQualificationID = Q.UserQualificationID " +
                "LEFT JOIN UserJob J ON C.UserJobID = J.UserJobID " +
                "LEFT JOIN Job Job ON J.JobID = Job.JobID " +  // Joining Job table to get JobName
                "LEFT JOIN UserImage I ON C.ImageID = I.ImageID " +
                "LEFT JOIN Appearance A ON C.AppearanceID = A.AppearanceID " +
                "LEFT JOIN UserReligion R ON C.UserReligionID = R.UserReligionID " +
                "LEFT JOIN Religion Religion ON R.ReligionID = Religion.ReligionID " +  // Joining Religion table to get ReligionType
                "LEFT JOIN Expectations E ON C.ExpID = E.ExpID " +
                "WHERE C.UserID = ?";

            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, UserID); // Set the UserID parameter
            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                // Main panel to hold all details
                JPanel mainPanel = new JPanel();
                mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS)); // Stack panels vertically
                mainPanel.setBackground(Color.WHITE);
                mainPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

                // Candidate Personal Details Panel
                JPanel userPanel = createSectionPanel("Candidate Details", new Color(224, 176, 176),
                        "Name: " + rs.getString("FirstName") + " " + rs.getString("LastName"),
                        "Email: " + rs.getString("Email"),
                        "Phone: " + rs.getString("Phone"),
                        "City: " + rs.getString("City"),
                        "Country: " + rs.getString("Country"),
                        "Date of Birth: " + rs.getDate("DateOfBirth"),
                        "Mother Tongue: " + rs.getString("MotherTongue"),
                        "Caste: " + rs.getString("Caste"),
                        "Marital Status: " + rs.getString("MaritalStatus"),
                        "Gender: " + rs.getString("Gender")
                );
                mainPanel.add(userPanel);

                // Candidate Qualification Panel
                JPanel qualificationPanel = createSectionPanel("Qualification", new Color(224, 176, 176),
                        "University: " + rs.getString("University"),
                        "Major Course: " + rs.getString("MajorCourse"),
                        "Profession: " + rs.getString("QualificationProfession")
                );
                mainPanel.add(qualificationPanel);

                // Candidate Job Panel
                JPanel jobPanel = createSectionPanel("Job Details", new Color(224, 176, 176),
                         "Job Name: " + rs.getString("JobName"),
                        "Monthly Income: " + rs.getDouble("JobMonthlyIncome"),
                        "Future Plan: " + rs.getString("JobFuturePlan")
                );
                mainPanel.add(jobPanel);

                // Candidate Appearance Panel
                JPanel appearancePanel = createSectionPanel("Appearance",new Color(224, 176, 176),
                        "Disability: " + rs.getString("AppearanceDisability"),
                        "Height: " + rs.getDouble("AppearanceHeight"),
                        "Smoke: " + rs.getString("AppearanceSmoke"),
                        "Complexion: " + rs.getString("AppearanceComplexion"),
                        "Hair Color: " + rs.getString("AppearanceHairColor"),
                        "Weight: " + rs.getDouble("AppearanceWeight"),
                        "Build: " + rs.getString("AppearanceBuild"),
                        "Eye Color: " + rs.getString("AppearanceEyeColor")
                );
                mainPanel.add(appearancePanel);

                // Candidate Religion Panel
                JPanel religionPanel = createSectionPanel("Religion Details", new Color(224, 176, 176),
                        "Religion Type: " + rs.getString("ReligionType"),
                        "Keep Halal: " + rs.getString("ReligionKeepHalal"),
                        "Hijab Preference: " + rs.getString("ReligionHijabPreference"),
                        "Beard Preference: " + rs.getString("ReligionBeardPreference"),
                        "Converted Religion: " + rs.getString("ReligionConvertedReligion"),
                        "Sect: " + rs.getString("ReligionSect"),
                        "Perform Salah: " + rs.getString("ReligionPerformSalah")
                );
                mainPanel.add(religionPanel);

                // Candidate Expectations Panel
                JPanel expectationsPanel = createSectionPanel("Expectations", new Color(224, 176, 176),
                        "Age From: " + rs.getInt("ExpectationsAgeFrom"),
                        "Age To: " + rs.getInt("ExpectationsAgeTo"),
                        "Gender: " + rs.getString("ExpectationsGender"),
                        "Country: " + rs.getString("ExpectationsCountry"),
                        "Mother Tongue: " + rs.getString("ExpectationsMotherTongue"),
                        "Sect: " + rs.getString("ExpectationsSect"),
                        "Profession: " + rs.getString("ExpectationsProfession"),
                        "Marital Status: " + rs.getString("ExpectationsMaritalStatus"),
                        "Height: " + rs.getDouble("ExpectationsHeight"),
                        "Caste: " + rs.getString("ExpectationsCaste"),
                        "Religion: " + rs.getString("ExpectationsReligion"),
                        "Monthly Income: " + rs.getDouble("ExpectationsMonthlyIncome"),
                        "Build: " + rs.getString("ExpectationsBuild"),
                        "Disability: " + rs.getString("ExpectationsDisability")
                );
                mainPanel.add(expectationsPanel);

                // Add the main panel containing all sections to the UI
                add(new JScrollPane(mainPanel), BorderLayout.CENTER);
                revalidate();
                repaint();
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}



// Method to calculate age from Date of Birth
private int calculateAge(Date dateOfBirth) {
    int currentYear = Calendar.getInstance().get(Calendar.YEAR);
    int birthYear = dateOfBirth.toLocalDate().getYear();
    return currentYear - birthYear;
}



  private JPanel createSectionPanel(String title, Color bgColor, String... details) {
    JPanel panel = new JPanel();
    panel.setBackground(bgColor);
    panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS)); // Stack components vertically

    // Create border for the panel
    panel.setBorder(BorderFactory.createTitledBorder(
            BorderFactory.createLineBorder(new Color(128, 0, 0), 2), // Maroon border with thickness 2
            title, 
            TitledBorder.LEFT, // Title justification (LEFT, CENTER, RIGHT)
            TitledBorder.TOP, // Title position (TOP, BOTTOM, ABOVE_BOTTOM)
            new Font("Arial", Font.BOLD, 20), // Title font
            new Color(128, 0, 0) // Title color (dark maroon)
    ));

    // Adding space inside the border (between border and content)
    panel.setBorder(BorderFactory.createCompoundBorder(
            panel.getBorder(),
            BorderFactory.createEmptyBorder(10, 10, 10, 10) // Space inside the border
    ));

    // Create a panel to hold labels and data with equal spacing
    for (String detail : details) {
        JPanel detailPanel = new JPanel();
        detailPanel.setLayout(new BoxLayout(detailPanel, BoxLayout.X_AXIS)); // Arrange label and data horizontally

        JLabel label = new JLabel(detail);
        label.setForeground(new Color(128, 0, 0)); // Dark Maroon font color
        label.setFont(new Font("Arial", Font.BOLD, 14)); // Bold labels

        detailPanel.add(Box.createRigidArea(new Dimension(10, 0))); // Add space between label and data
        detailPanel.add(label);
        detailPanel.add(Box.createHorizontalGlue()); // Ensure that the label and data spread evenly

        panel.add(detailPanel); // Add detailPanel to the main panel
        panel.add(Box.createVerticalStrut(10)); // Add space between rows
    }

    return panel;
}

    private void initUI() {
        JPanel navbar = new JPanel();
        navbar.setBackground(new Color(128, 0, 0));
        navbar.setLayout(new BorderLayout());

        JLabel titleLabel = new JLabel("Candidate Details", SwingConstants.CENTER);
        
        titleLabel.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 50));
        titleLabel.setForeground(Color.WHITE);
        
        
        // Back button with increased size
        ImageIcon backIcon = new ImageIcon(new ImageIcon("src/backicon.png").getImage()
                .getScaledInstance(40, 40, Image.SCALE_SMOOTH));
        JButton backButton = new JButton(backIcon);
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.addActionListener(e -> dispose());

        navbar.add(backButton, BorderLayout.WEST);
        navbar.add(titleLabel, BorderLayout.CENTER);

        add(navbar, BorderLayout.NORTH);
    }



    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>                        

}
    