import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class PersonalInfoForm extends JFrame {
    private JTextField heightField, weightField;
    private JComboBox<String> complexionField, hairColorField, smokeField, buildField, eyeColorField, disabilityField;
    private int userID;
    private int AppearanceID;

    public PersonalInfoForm(int userID) {
        this.userID = userID;

        setTitle("Personal Information");
        setLayout(new GridLayout(16, 2));
        getContentPane().setBackground(new Color(128, 0, 0)); // Set background color to dark maroon

        // Height field
        add(createLabel("Height (in cm, e.g., 170.00):"));
        heightField = new JTextField();
        add(heightField);

        // Complexion field
        add(createLabel("Complexion:"));
        complexionField = new JComboBox<>(new String[]{"Fair", "Light", "Medium", "Tan", "Deep"});
        add(complexionField);

        // Hair color field
        add(createLabel("Hair Color:"));
        hairColorField = new JComboBox<>(new String[]{"Black", "Brown", "Grey", "White", "Other"});
        add(hairColorField);

        // Smoke field
        add(createLabel("Smoke:"));
        smokeField = new JComboBox<>(new String[]{"Yes", "No", "Sometimes"});
        add(smokeField);

        // Weight field
        add(createLabel("Weight (in kg, e.g., 70.00):"));
        weightField = new JTextField();
        add(weightField);

        // Build field
        add(createLabel("Build:"));
        buildField = new JComboBox<>(new String[]{"Slim", "Muscular", "Chubby", "Slender", "Heavyset"});
        add(buildField);

        // Eye color field
        add(createLabel("Eye Color:"));
        eyeColorField = new JComboBox<>(new String[]{"Brown", "Black", "Green", "Blue", "Grey", "Other"});
        add(eyeColorField);

        // Disability field
        add(createLabel("Disability:"));
        disabilityField = new JComboBox<>(new String[]{"None", "Physical", "Hearing Loss", "Mental Illness", "Intellectual", "Autism", "Hearing Impairment", "Speech", "Blindness"});
        add(disabilityField);

        // Next button to proceed
        JButton nextButton = new JButton("Next");
        nextButton.addActionListener(e -> insertAndProceed());
        add(nextButton);

        setSize(400, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    // Helper method to create JLabels with white font
    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE); // Set font color to white
        return label;
    }

    private void insertAndProceed() {
        String height = heightField.getText().trim();
        String weight = weightField.getText().trim();
        String complexion = (String) complexionField.getSelectedItem();
        String hairColor = (String) hairColorField.getSelectedItem();
        String smoke = (String) smokeField.getSelectedItem();
        String build = (String) buildField.getSelectedItem();
        String eyeColor = (String) eyeColorField.getSelectedItem();
        String disability = (String) disabilityField.getSelectedItem();

        // Validate height and weight to ensure they are DECIMAL(5,2)
        if (!isValidDecimal(height) || !isValidDecimal(weight)) {
            JOptionPane.showMessageDialog(this, "Height and Weight must be valid decimal values (e.g., 170.00, 75.00).");
            return;
        }

        String query = "INSERT INTO Appearance (Disability, Height, Smoke, Complexion, HairColor, Weight, Build, EyeColor) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = DatabaseConnection.connect();
             PreparedStatement ps = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            // Set the parameters for the insert
            ps.setString(1, disability);
            ps.setBigDecimal(2, new java.math.BigDecimal(height));  // Storing as DECIMAL(5,2)
            ps.setString(3, smoke);
            ps.setString(4, complexion);
            ps.setString(5, hairColor);
            ps.setBigDecimal(6, new java.math.BigDecimal(weight));  // Storing as DECIMAL(5,2)
            ps.setString(7, build);
            ps.setString(8, eyeColor);

            // Execute the insert
            ps.executeUpdate();

            // Get the generated AppearanceID
            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    AppearanceID = generatedKeys.getInt(1);  // Retrieve the generated AppearanceID
                }
            }

            JOptionPane.showMessageDialog(this, "Appearance details saved successfully!");

            // Proceed to the next form and pass the AppearanceID
            new ReligionInfoForm(userID, AppearanceID).setVisible(true);
            this.dispose();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }
    }

    // Helper method to validate if a string is a valid decimal number with two decimal places
    private boolean isValidDecimal(String value) {
        try {
            java.math.BigDecimal decimal = new java.math.BigDecimal(value);
            return decimal.scale() <= 2; // Check if the decimal value has more than two decimal places
        } catch (NumberFormatException e) {
            return false;
        }
    }

    public static void main(String[] args) {
        // Example call to the form with a sample userID
        new PersonalInfoForm(1);
    }
}
