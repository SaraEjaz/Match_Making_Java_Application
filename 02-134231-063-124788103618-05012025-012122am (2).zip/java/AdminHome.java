
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.Ellipse2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.sql.*;
import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import java.awt.Color;




public class AdminHome extends JFrame {

    private JPanel userPanel;
    private int adminID;  // Admin ID passed dynamically

    public AdminHome(int adminID) {
        this.adminID = adminID;  // Set the dynamic AdminID
        

        setTitle("Admin Home");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 800);
        setLocationRelativeTo(null);

        initComponent();
        fetchUserData();
    }

    private void initComponent() {
        setLayout(new BorderLayout());

        JPanel navBar = createNavBar();
        add(navBar, BorderLayout.NORTH);

        JPanel centerPanel = new JPanel(new BorderLayout());
        centerPanel.setBorder(new EmptyBorder(10, 10, 10, 10));

        userPanel = new JPanel();
        userPanel.setLayout(new BoxLayout(userPanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(userPanel);
        centerPanel.add(scrollPane, BorderLayout.CENTER);

        add(centerPanel, BorderLayout.CENTER);
    }

    private JPanel createNavBar() {
    JPanel navBar = new JPanel();
    navBar.setBackground(new java.awt.Color(128, 0, 0));
    navBar.setLayout(new BorderLayout());
    navBar.setPreferredSize(new Dimension(getWidth(), 80));

    // Left button with popup menu
    JButton leftButton = new JButton(new ImageIcon(getClass().getResource("/baricon.png")));
    leftButton.setBackground(new java.awt.Color(128, 0, 0));
    leftButton.setBorder(BorderFactory.createEmptyBorder());

    JPopupMenu popupMenu = new JPopupMenu();

    // Profile menu item
    JMenuItem profileMenuItem = new JMenuItem("Profile");
    profileMenuItem.addActionListener(e -> new ViewProfileFrame(adminID));

    // Update Profile menu item
    JMenuItem updateProfileMenuItem = new JMenuItem("Update My Profile");
    updateProfileMenuItem.addActionListener(e -> new UpdateProfileFrame(adminID));

    // View Assigned Candidates menu item
    JMenuItem viewAssignedCandidatesMenuItem = new JMenuItem("View Assigned Candidates");
    viewAssignedCandidatesMenuItem.addActionListener(e -> {
        new viewAssignedCandidates(adminID).setVisible(true); // Open the ViewAssignedCandidates frame
        this.dispose(); // Close the current AdminHome window
    });

    // Add menu items to the popup menu
    popupMenu.add(profileMenuItem);
    popupMenu.add(updateProfileMenuItem);
    popupMenu.add(viewAssignedCandidatesMenuItem);

    leftButton.addActionListener(e -> popupMenu.show(leftButton, 0, leftButton.getHeight()));

    // Right button with user menu
    JButton rightButton = new JButton(new ImageIcon(getClass().getResource("/usericon.png")));
    rightButton.setBackground(new java.awt.Color(128, 0, 0));
    rightButton.setBorder(BorderFactory.createEmptyBorder());

    JPopupMenu userPopupMenu = new JPopupMenu();

    // Logout menu item
    JMenuItem logoutMenuItem = new JMenuItem("Logout");
    logoutMenuItem.addActionListener(e -> logout()); // Call the logout method
    userPopupMenu.add(logoutMenuItem);

    rightButton.addActionListener(e -> userPopupMenu.show(rightButton, 0, rightButton.getHeight()));

    // Title in the center of the navbar
    JLabel titleLabel = new JLabel("Shaadi.com", JLabel.CENTER);
    titleLabel.setFont(new Font("Serif", Font.BOLD | Font.ITALIC, 50));
    titleLabel.setForeground(Color.WHITE);

    // Add components to the navbar
    navBar.add(leftButton, BorderLayout.WEST);
    navBar.add(titleLabel, BorderLayout.CENTER);
    navBar.add(rightButton, BorderLayout.EAST);

    return navBar;
}

 private void logout() {
    // You can perform any necessary cleanup here, like clearing session or cache if applicable.
    
    // Redirect to SignInPage
    this.dispose(); // Close the current AdminHome window
    new SignInPage().setVisible(true); // Open the SignInPage
}
    private void fetchUserData() {
        try (Connection connection = DatabaseConnection.connect()) {
            if (connection != null) {
                String query = "SELECT u.UserID, c.CandidateID, u.FirstName, u.LastName, u.Email, u.Phone, u.City, u.Country, u.MaritalStatus, u.DateOfBirth, im.Picture, u.isVerified " +
                               "FROM [user] u " +
                               "JOIN Candidate c ON u.UserID = c.UserID " +
                               "JOIN UserImage im ON c.ImageID = im.ImageID " +
                               "WHERE UserType != 'admin'"; // Ensuring we select candidates only

                Statement stmt = connection.createStatement();
                ResultSet rs = stmt.executeQuery(query);

                userPanel.removeAll();
                userPanel.revalidate();
                userPanel.repaint();

                while (rs.next()) {
                    JPanel userInfoPanel = new JPanel();
                    userInfoPanel.setLayout(new FlowLayout(FlowLayout.LEFT, 70, 50));
                    userInfoPanel.setBorder(new LineBorder(new java.awt.Color(128, 0, 0), 2, true));
                    userInfoPanel.setFont(new Font("Arial", Font.BOLD, 14));
                    userInfoPanel.setForeground(Color.MAGENTA);

                    String fullName = rs.getString("FirstName") + " " + rs.getString("LastName");
                    String email = rs.getString("Email");
                    String phone = rs.getString("Phone");
                    String city = rs.getString("City");
                    String country = rs.getString("Country");
                    String maritalStatus = rs.getString("MaritalStatus");
                    String dateOfBirth = rs.getDate("DateOfBirth").toString();
                    int userID = rs.getInt("UserID"); // Get the userID of the candidate
                    int candidateID = rs.getInt("CandidateID"); // Get the CandidateID
                    String isVerified = rs.getString("isVerified");

                    byte[] imageBytes = rs.getBytes("Picture");
                    BufferedImage img = (imageBytes != null) ? ImageIO.read(new ByteArrayInputStream(imageBytes)) : null;
                    JLabel imageLabel = createCircularImage(img);

                    JPanel infoPanel = new JPanel();
                    infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
                    infoPanel.add(new JLabel("Name: " + fullName));
                    infoPanel.add(new JLabel("Email: " + email));
                    infoPanel.add(new JLabel("Phone: " + phone));
                    infoPanel.add(new JLabel("City: " + city));
                    infoPanel.add(new JLabel("Country: " + country));
                    infoPanel.add(new JLabel("Marital Status: " + maritalStatus));
                    infoPanel.add(new JLabel("Date of Birth: " + dateOfBirth));

                    userInfoPanel.add(imageLabel);
                    userInfoPanel.add(Box.createHorizontalStrut(20));
                    userInfoPanel.add(infoPanel);

                    JPanel buttonPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));

                    if ("Yes".equals(isVerified)) {
                        JLabel verifiedLabel = new JLabel("Verified");
                        verifiedLabel.setFont(new Font("Arial", Font.BOLD, 14));
                        verifiedLabel.setForeground(new java.awt.Color(128, 0, 0));
                        buttonPanel.add(Box.createHorizontalStrut(20));
                        buttonPanel.add(verifiedLabel);
                    } else {
                        JButton verifyButton = new JButton("Verify");
                        verifyButton.setBackground(new java.awt.Color(128, 0, 0));
                        verifyButton.setForeground(Color.WHITE);
                        verifyButton.addActionListener(e -> verifyCandidate(userID, buttonPanel, userInfoPanel));
                        buttonPanel.add(verifyButton);
                    }

                    buttonPanel.add(Box.createHorizontalStrut(20));

                    // "View Candidate" Button
                    JButton viewCandidateButton = new JButton("View Candidate");
                    viewCandidateButton.setBackground(new java.awt.Color(128, 0, 0));
                    viewCandidateButton.setForeground(Color.WHITE);
                    viewCandidateButton.addActionListener(e -> {
    ViewCandidateFrame viewCandidateFrame = new ViewCandidateFrame(userID); // Pass userID instead of candidateID
    viewCandidateFrame.setVisible(true); // Make the frame visible
});


                    buttonPanel.add(viewCandidateButton);

                  
                    userInfoPanel.add(buttonPanel);
                    userPanel.add(userInfoPanel);
                }
            }
        } catch (SQLException | IOException e) {
            e.printStackTrace();
        }
    }

    

    // Method to create circular image label
    private JLabel createCircularImage(BufferedImage img) {
        if (img == null) {
            return new JLabel("No Image");
        }

        int width = 80;
        int height = 80;

        ImageIcon imageIcon = new ImageIcon(img.getScaledInstance(width, height, Image.SCALE_SMOOTH));
        Image image = imageIcon.getImage();
        BufferedImage output = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g2d = output.createGraphics();
        g2d.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

        g2d.setClip(new Ellipse2D.Double(0, 0, width, height));
        g2d.drawImage(image, 0, 0, null);
        g2d.dispose();

        return new JLabel(new ImageIcon(output));
    }

    // Method to handle verifying a candidate
private void verifyCandidate(int userID, JPanel buttonPanel, JPanel userInfoPanel) {
    try (Connection connection = DatabaseConnection.connect()) {
        if (connection != null) {
            String query = "UPDATE [user] SET isVerified = 'Yes' WHERE UserID = ?";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, userID);

            stmt.executeUpdate();
            JOptionPane.showMessageDialog(this, "Candidate verified successfully!");

            // Update UI elements
            buttonPanel.removeAll();
            JLabel verifiedLabel = new JLabel("Verified");
            verifiedLabel.setFont(new Font("Arial", Font.BOLD, 14));
            verifiedLabel.setForeground(new java.awt.Color(128, 0, 0));
            buttonPanel.add(Box.createHorizontalStrut(20));
            buttonPanel.add(verifiedLabel);

            // Add the "View Candidate" button back to the panel
            JButton viewCandidateButton = new JButton("View Candidate");
            viewCandidateButton.setBackground(new java.awt.Color(128, 0, 0));
            viewCandidateButton.setForeground(Color.WHITE);
            viewCandidateButton.addActionListener(e -> {
                ViewCandidateFrame viewCandidateFrame = new ViewCandidateFrame(userID); // Pass userID instead of candidateID
                viewCandidateFrame.setVisible(true); // Make the frame visible
            });
            buttonPanel.add(viewCandidateButton);

            userInfoPanel.revalidate();
            userInfoPanel.repaint();
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}
  

    // Variables declaration - do not modify                     
    // End of variables declaration
    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>                        
 
 
}

    // Variables declaration - do not modify                     
    // End of variables declaration