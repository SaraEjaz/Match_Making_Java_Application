import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.Color;

public class viewAssignedCandidates extends JFrame {

    private int adminID;  // This will store the actual admin ID fetched from the Admin table
    private JPanel candidatesPanel;  // Panel to hold all candidate panels
    private int userID;  // This will store the UserID passed to the frame

    public viewAssignedCandidates(int userID) {
        this.userID = userID;  // Store the UserID passed from AdminHome
        initComponent();
        fetchAdminID();  // Fetch the adminID based on the userID
    }

    private void initComponent() {
        setTitle("Assigned Candidates");

        // Navbar setup
        JPanel navbarPanel = new JPanel();
        navbarPanel.setLayout(new BorderLayout());
        navbarPanel.setBackground(new Color(128, 0, 0));  // Maroon color for the navbar

        // Back icon
        ImageIcon backIcon = new ImageIcon(getClass().getResource("/backicon.png"));
        JLabel backLabel = new JLabel(backIcon);
        backLabel.setCursor(new Cursor(Cursor.HAND_CURSOR));
        backLabel.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                dispose();  // Close the current window when back icon is clicked
                openAdminHome();  // Open AdminHome window
            }
        });

        // Title label
        JLabel titleLabel = new JLabel("Assigned Candidates");
        titleLabel.setFont(new Font("Arial", Font.BOLD, 18));
        titleLabel.setForeground(Color.WHITE);
        titleLabel.setHorizontalAlignment(JLabel.CENTER);

        // Add components to navbar panel
        navbarPanel.add(backLabel, BorderLayout.WEST);
        navbarPanel.add(titleLabel, BorderLayout.CENTER);

        // Create a panel to hold the candidate panels
        candidatesPanel = new JPanel();
        candidatesPanel.setLayout(new BoxLayout(candidatesPanel, BoxLayout.Y_AXIS));  // Layout for vertical stacking

        // Add the candidates panel to a scroll pane for better navigation
        JScrollPane scrollPane = new JScrollPane(candidatesPanel);
        getContentPane().add(navbarPanel, BorderLayout.NORTH);  // Add navbar at the top
        getContentPane().add(scrollPane, BorderLayout.CENTER);

        // Set the size of the frame
        setSize(800, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);  // Center the window
    }

    // Fetch the adminID from the Admin table based on the UserID
    private void fetchAdminID() {
        String query = "SELECT Admin_ID FROM Admin WHERE UserID = ?";

        try (Connection conn = DatabaseConnection.connect();  // Use DatabaseConnection class
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setInt(1, userID);  // Set the passed userID to the query
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                adminID = rs.getInt("Admin_ID");  // Get the adminID
                fetchAssignedCandidates();  // Now fetch the assigned candidates using adminID
            } else {
                JOptionPane.showMessageDialog(this, "Admin not found for the given UserID", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Fetch the assigned candidates using the adminID as ConsultantID
    private void fetchAssignedCandidates() {
        String query = "SELECT u.FirstName, u.LastName, u.Phone, u.Email, u.City, r.ReligionType AS Religion, ui.Picture AS CandidatePicture, u.UserID " +
                       "FROM userPackages up " +
                       "INNER JOIN Candidate c ON up.candidateid = c.CandidateID " +
                       "INNER JOIN [User] u ON c.UserID = u.UserID " +
                       "INNER JOIN UserReligion ur ON c.UserReligionID = ur.UserReligionID " +
                       "INNER JOIN Religion r ON ur.ReligionID = r.ReligionID " +
                       "INNER JOIN UserImage ui ON c.ImageID = ui.ImageID " +
                       "WHERE up.Consultantid = ?";

        try (Connection conn = DatabaseConnection.connect();  // Use DatabaseConnection class
             PreparedStatement ps = conn.prepareStatement(query)) {
            
            ps.setInt(1, adminID);  // Set the adminID as ConsultantID in the query
            ResultSet rs = ps.executeQuery();

            // Clear any previous candidate panels
            candidatesPanel.removeAll();

            // Process the result set and create a panel for each candidate
            while (rs.next()) {
                JPanel candidatePanel = new JPanel();
                candidatePanel.setLayout(new FlowLayout(FlowLayout.LEFT, 20, 10));  // Use FlowLayout with padding
                candidatePanel.setBackground(new Color(241, 208, 214));  // Light maroon background color
                candidatePanel.setBorder(BorderFactory.createLineBorder(new Color(128, 0, 0), 3));  // Dark maroon border

                // Create an image label for the candidate's passport-sized picture
                byte[] imageBytes = rs.getBytes("CandidatePicture");
                ImageIcon imageIcon = new ImageIcon(imageBytes);
                Image image = imageIcon.getImage().getScaledInstance(100, 100, Image.SCALE_SMOOTH);  // Resize to 100x100
                imageIcon = new ImageIcon(image);
                JLabel pictureLabel = new JLabel(imageIcon);

                // Create a panel for candidate data (name, phone, email, etc.)
                JPanel dataPanel = new JPanel();
                dataPanel.setLayout(new BoxLayout(dataPanel, BoxLayout.Y_AXIS));  // Stack vertically
                dataPanel.setBackground(new Color(241, 208, 214));  // Same light maroon background color

                // Create labels for each piece of data
                JLabel firstNameLabel = new JLabel("First Name: " + rs.getString("FirstName"));
                JLabel lastNameLabel = new JLabel("Last Name: " + rs.getString("LastName"));
                JLabel phoneLabel = new JLabel("Phone: " + rs.getString("Phone"));
                JLabel emailLabel = new JLabel("Email: " + rs.getString("Email"));
                JLabel cityLabel = new JLabel("City: " + rs.getString("City"));
                JLabel religionLabel = new JLabel("Religion: " + rs.getString("Religion"));

                // Add all labels to the data panel
                dataPanel.add(firstNameLabel);
                dataPanel.add(lastNameLabel);
                dataPanel.add(phoneLabel);
                dataPanel.add(emailLabel);
                dataPanel.add(cityLabel);
                dataPanel.add(religionLabel);

                // Create the View Candidate Button
                int candidateUserID = rs.getInt("UserID");
                JButton viewCandidateButton = new JButton("View Candidate");
                viewCandidateButton.setBackground(new Color(128, 0, 0));  // Maroon color
                viewCandidateButton.setForeground(Color.WHITE);
                viewCandidateButton.setFocusPainted(false);
                viewCandidateButton.setBorderPainted(false);
                viewCandidateButton.addActionListener(e -> openViewCandidateFrame(candidateUserID));  // Action for button click

                // Add the picture, data panel, and button to the candidate panel
                candidatePanel.add(pictureLabel);  // Image on the left side
                candidatePanel.add(dataPanel);     // Data on the right side
                candidatePanel.add(viewCandidateButton);  // View button at the bottom

                // Add the candidate panel to the main panel
                candidatesPanel.add(candidatePanel);
            }

            // Refresh the candidates panel to reflect the new data
            candidatesPanel.revalidate();
            candidatesPanel.repaint();

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Method to open the ViewCandidateFrame with the UserID
    private void openViewCandidateFrame(int candidateUserID) {
        ViewCandidateFrame viewCandidateFrame = new ViewCandidateFrame(candidateUserID);
        viewCandidateFrame.setVisible(true);  // Show the ViewCandidateFrame
    }

    private void openAdminHome() {
        // Assuming AdminHome takes userID as a parameter
        AdminHome adminHome = new AdminHome(userID);
        adminHome.setVisible(true);  // Show the AdminHome window
    }

  

    // <editor-fold defaultstate="collapsed" desc="Generated Code">                          
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>                        

    
    
    // Variables declaration - do not modify                     
    // End of variables declaration                   
}