
import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.text.SimpleDateFormat;

public class ViewProfileFrame extends JFrame {

    private int userID;

    public ViewProfileFrame(int userID) {
        this.userID = userID;  // Set the userID from the constructor
        setTitle("View Profile");
        setSize(1200, 800);
        setLocationRelativeTo(null);

        // Create content panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BorderLayout());

        // Add navbar
        JPanel navBar = createNavBar();
        contentPanel.add(navBar, BorderLayout.NORTH);

        // Create table panel where the details will be displayed
        JPanel tablePanel = new JPanel();
        tablePanel.setLayout(new BorderLayout());

        // Fetch user data and display it in a JTable
        fetchProfileData(tablePanel);

        // Add table panel to the content panel below the navbar
        contentPanel.add(tablePanel, BorderLayout.CENTER);

        // Add content panel to the frame
        add(contentPanel);

        setVisible(true);
    }

    private void fetchProfileData(JPanel tablePanel) {
    try (Connection connection = DatabaseConnection.connect()) {
        if (connection != null) {
            String query = "SELECT FirstName, LastName, Email, Phone, City, Country, MaritalStatus, DateOfBirth " +
                           "FROM [user] WHERE UserID = ?";
            PreparedStatement stmt = connection.prepareStatement(query);
            stmt.setInt(1, userID);  // Use the userID passed into the constructor
            ResultSet rs = stmt.executeQuery();

            // Column names for the table
            String[] columnNames = {"Field", "Value"};
            DefaultTableModel tableModel = new DefaultTableModel(columnNames, 0);

            if (rs.next()) {
                // Data for the table
                String[] labels = {"First Name", "Last Name", "Email", "Phone", "City", "Country", "Marital Status", "Date of Birth"};
                String[] values = {
                    rs.getString("FirstName"),
                    rs.getString("LastName"),
                    rs.getString("Email"),
                    rs.getString("Phone"),
                    rs.getString("City"),
                    rs.getString("Country"),
                    rs.getString("MaritalStatus"),
                    new SimpleDateFormat("MM/dd/yyyy").format(rs.getDate("DateOfBirth"))  // Format the date
                };

                // Add data to the table model
                for (int i = 0; i < labels.length; i++) {
                    tableModel.addRow(new Object[] { labels[i], values[i] });
                }
            }

            // Create the table with the model
            JTable table = new JTable(tableModel);
            table.setFont(new Font("Arial", Font.BOLD, 16));  // Make the table text bold
            table.setRowHeight(30);  // Increase row height for better visibility

            // Customize table appearance with maroon shades
            table.setBackground(new Color(255, 235, 235));  // Light maroon background for table
            table.setGridColor(new Color(128, 0, 0));  // Maroon grid lines

            // Customizing the header with a darker shade of maroon
            table.getTableHeader().setBackground(new Color(139, 0, 0));  // Dark maroon header
            table.getTableHeader().setForeground(Color.WHITE);  // White text in the header
            table.getTableHeader().setFont(new Font("Arial", Font.BOLD, 16));  // Bold font for header

            // Alternate row colors for better readability
            table.setDefaultRenderer(Object.class, (table1, value, isSelected, hasFocus, row, column) -> {
                JLabel label = new JLabel();
                label.setOpaque(true);
                label.setFont(new Font("Arial", Font.PLAIN, 16));  // Regular font for values

                // Set different background colors for odd and even rows
                if (row % 2 == 0) {
                    label.setBackground(new Color(255, 235, 235));  // Light maroon for even rows
                } else {
                    label.setBackground(new Color(255, 200, 200));  // Slightly darker maroon for odd rows
                }

                // Set foreground color for text
                label.setText(value == null ? "" : value.toString());
                return label;
            });

            // Add the table to a scroll pane
            JScrollPane scrollPane = new JScrollPane(table);
            tablePanel.add(scrollPane, BorderLayout.CENTER);
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
}


    private JPanel createNavBar() {
        JPanel navBar = new JPanel();
        navBar.setBackground(new Color(128, 0, 0));  // Maroon background
        navBar.setLayout(new BorderLayout());
        navBar.setPreferredSize(new Dimension(getWidth(), 80));

        // Admin Profile title
        JLabel titleLabel = new JLabel("Admin Profile", JLabel.CENTER);
        titleLabel.setFont(new Font("Arial", Font.BOLD | Font.ITALIC, 30));  // Adjust font size and style
        titleLabel.setForeground(Color.WHITE);  // Set font color to white
        navBar.add(titleLabel, BorderLayout.CENTER);

        // Back Button
        JButton backButton = new JButton(new ImageIcon(getClass().getResource("/backicon.png")));  // Load the icon
        backButton.setBackground(new Color(128, 0, 0));  // Same maroon color for consistency
        backButton.setBorder(BorderFactory.createEmptyBorder());  // Remove the border
        backButton.setContentAreaFilled(false);  // Remove the button background fill
        backButton.addActionListener(e -> {
    dispose();  // Close the current window
    SwingUtilities.invokeLater(() -> new AdminHome(userID).setVisible(true));  // Pass adminID
});

        navBar.add(backButton, BorderLayout.WEST);

        return navBar;
    }

  
   
    
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
   
}