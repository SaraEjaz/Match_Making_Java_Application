import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CareerInfoForm extends JFrame {
    private JComboBox<String> qualificationsBox, universityBox, majorCourseBox, professionBox, jobBox, futurePlanBox;
    private JTextField monthlyIncomeField;
    private int userID;
 private int AppearanceID;
  private int UserReligionID;
  private int UserQualificationID;
  private int UserJobID;
    public CareerInfoForm(int userID,int AppearanceID,int UserReligionID) {
        this.userID = userID;
        this.AppearanceID=AppearanceID;
        this.UserReligionID=UserReligionID;
        setTitle("Career Information");
        setLayout(new GridLayout(8, 2));
        // Set background color to dark maroon
        getContentPane().setBackground(new Color(128, 0, 0));
        // Qualification Dropdown (from Qualification table)
JLabel qualificationLabel = new JLabel("Qualification:");
qualificationLabel.setForeground(Color.WHITE);
add(qualificationLabel);
qualificationsBox = new JComboBox<>(getQualifications());
add(qualificationsBox);

// University Dropdown
JLabel universityLabel = new JLabel("University:");
universityLabel.setForeground(Color.WHITE);
add(universityLabel);
String[] universityOptions = {
    "Harvard", "MIT", "Stanford", "Oxford", "Cambridge",
    "UCLA", "Columbia", "Caltech", "Yale", "Princeton",
    "LUMS", "NUST", "IBA", "Other"
};
universityBox = new JComboBox<>(universityOptions);
add(universityBox);

// Major Course Dropdown
JLabel majorCourseLabel = new JLabel("Major Course:");
majorCourseLabel.setForeground(Color.WHITE);
add(majorCourseLabel);
String[] majorCourseOptions = {
    "Computer Science", "Mathematics", "Physics", "Medicine", "Economics",
    "Business", "Law", "Engineering", "Psychology", "Biology", "Other"
};
majorCourseBox = new JComboBox<>(majorCourseOptions);
add(majorCourseBox);

// Profession Dropdown
JLabel professionLabel = new JLabel("Profession:");
professionLabel.setForeground(Color.WHITE);
add(professionLabel);
String[] professionOptions = {
    "Software Developer", "Doctor", "Engineer", "Professor", "Scientist",
    "Business Analyst", "Lawyer", "Artist", "Entrepreneur", "Writer", "Other"
};
professionBox = new JComboBox<>(professionOptions);
add(professionBox);

// Job Dropdown (from Job table)
JLabel jobLabel = new JLabel("Job:");
jobLabel.setForeground(Color.WHITE);
add(jobLabel);
jobBox = new JComboBox<>(getJobs());
add(jobBox);

// Monthly Income Field
JLabel incomeLabel = new JLabel("Monthly Income (in USD):");
incomeLabel.setForeground(Color.WHITE);
add(incomeLabel);
monthlyIncomeField = new JTextField();
add(monthlyIncomeField);

// Future Plan Dropdown
JLabel futurePlanLabel = new JLabel("Future Plan:");
futurePlanLabel.setForeground(Color.WHITE);
add(futurePlanLabel);
String[] futurePlanOptions = {
    "Save and Invest", "Financial Planning and Savings", "Prioritizing Family", "Pursue Further Education"
};
futurePlanBox = new JComboBox<>(futurePlanOptions);
add(futurePlanBox);

  
        // Next Button
        JButton nextButton = new JButton("Next");
        nextButton.addActionListener(e -> {
            try {
                insertAndProceed();
            } catch (SQLException ex) {
                Logger.getLogger(CareerInfoForm.class.getName()).log(Level.SEVERE, null, ex);
            }
        });
        add(nextButton);
        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    // Fetch qualifications from the database
    private String[] getQualifications() {
        try (Connection con = DatabaseConnection.connect();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT QualificationType FROM Qualification")) {
            return rsToArray(rs);
        } catch (SQLException e) {
            e.printStackTrace();
            return new String[]{"Error loading qualifications"};
        }
    }

    // Fetch job names from the database
    private String[] getJobs() {
        try (Connection con = DatabaseConnection.connect();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT JobName FROM Job")) {
            return rsToArray(rs);
        } catch (SQLException e) {
            e.printStackTrace();
            return new String[]{"Error loading jobs"};
        }
    }

    // Helper method to convert ResultSet to String array
    private String[] rsToArray(ResultSet rs) throws SQLException {
        java.util.List<String> list = new java.util.ArrayList<>();
        while (rs.next()) {
            list.add(rs.getString(1));
        }
        return list.toArray(new String[0]);
    }

private void insertAndProceed() throws SQLException {
    String qualification = (String) qualificationsBox.getSelectedItem();
    String university = (String) universityBox.getSelectedItem();
    String majorCourse = (String) majorCourseBox.getSelectedItem();
    String profession = (String) professionBox.getSelectedItem();
    String job = (String) jobBox.getSelectedItem();
    String futurePlan = (String) futurePlanBox.getSelectedItem();
    String monthlyIncomeStr = monthlyIncomeField.getText().trim();

    if (!isValidDecimal(monthlyIncomeStr)) {
        JOptionPane.showMessageDialog(this, "Monthly Income must be a valid number.");
        return;
    }

    BigDecimal monthlyIncome = new BigDecimal(monthlyIncomeStr);

    try (Connection con = DatabaseConnection.connect()) {
        con.setAutoCommit(false);

        // Insert into UserQualification
        String qualificationQuery = "INSERT INTO UserQualification (QualificationID, University, MajorCourse, Profession) " +
                                     "VALUES ((SELECT QualificationID FROM Qualification WHERE QualificationType = ?), ?, ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(qualificationQuery, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, qualification);
            ps.setString(2, university);
            ps.setString(3, majorCourse);
            ps.setString(4, profession);
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    UserQualificationID = rs.getInt(1);
                }
            }
        }

        // Insert into UserJob
        String jobQuery = "INSERT INTO UserJob (JobID, MonthlyIncome, FuturePlan) " +
                          "VALUES ((SELECT JobID FROM Job WHERE JobName = ?), ?, ?)";
        try (PreparedStatement ps = con.prepareStatement(jobQuery, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, job);
            ps.setBigDecimal(2, monthlyIncome);
            ps.setString(3, futurePlan);
            ps.executeUpdate();

            try (ResultSet rs = ps.getGeneratedKeys()) {
                if (rs.next()) {
                    UserJobID = rs.getInt(1);
                }
            }
        }

        con.commit();

        // Proceed to the next form
        new ExpectationsForm(userID, AppearanceID, UserReligionID, UserQualificationID, UserJobID).setVisible(true);
        this.dispose();
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
    }
}
    // Helper method to validate decimal input
    // Helper method to validate decimal input
    private boolean isValidDecimal(String value) {
        try {
            new BigDecimal(value);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
      public static void main(String[] args) {
        new CareerInfoForm(1,1,1);
    }
}