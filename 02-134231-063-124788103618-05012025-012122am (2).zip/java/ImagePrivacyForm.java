import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
import java.sql.*;

public class ImagePrivacyForm extends JFrame {
    private JComboBox<String> whoCanSeePictureField;
    private JLabel imageLabel;
    private JButton uploadButton, registerButton;
    private File selectedFile;
    private int userID;
    private int AppearanceID;
    private int UserReligionID;
    private int UserQualificationID;
    private int UserJobID;
    private int expectationID;

    public ImagePrivacyForm(int userID, int AppearanceID, int UserReligionID, int UserQualificationID, int UserJobID, int expectationID) {
        this.userID = userID;
        this.AppearanceID = AppearanceID;
        this.UserReligionID = UserReligionID;
        this.UserQualificationID = UserQualificationID;
        this.UserJobID = UserJobID;
        this.expectationID = expectationID;

        setTitle("Image Privacy");
        setLayout(new GridLayout(4, 2));
        // Set background color to dark maroon
        getContentPane().setBackground(new Color(128, 0, 0));

        // Who Can See Picture
        JLabel whoCanSeeLabel = new JLabel("Who Can See Picture:");
        whoCanSeeLabel.setForeground(Color.WHITE); // Set font color to white
        add(whoCanSeeLabel);

        whoCanSeePictureField = new JComboBox<>(new String[]{"Everyone", "Only Me"});
        add(whoCanSeePictureField);

        // Image Preview
        imageLabel = new JLabel("No Image Selected", SwingConstants.CENTER);
        imageLabel.setForeground(Color.WHITE); // Set font color to white
        imageLabel.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        add(imageLabel);

        // Upload Button
        uploadButton = new JButton("Upload Image");
        uploadButton.addActionListener(e -> uploadImage());
        add(uploadButton);

        // Register Button
        registerButton = new JButton("Register");
        registerButton.addActionListener(e -> insertImagePrivacy());
        add(registerButton);

        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

private void uploadImage() {
    JFileChooser fileChooser = new JFileChooser();
    // Updated filter to accept all image file types
    fileChooser.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Image files", "jpg", "jpeg", "png", "bmp", "gif", "tiff", "webp"));
    int returnValue = fileChooser.showOpenDialog(this);
    if (returnValue == JFileChooser.APPROVE_OPTION) {
        selectedFile = fileChooser.getSelectedFile();
        imageLabel.setText(selectedFile.getName());
    } else {
        selectedFile = null;
        imageLabel.setText("No Image Selected");
    }
}

    private void insertImagePrivacy() {
        String whoCanSeePicture = (String) whoCanSeePictureField.getSelectedItem();

        if (selectedFile == null) {
            JOptionPane.showMessageDialog(this, "Please upload an image before registering.");
            return;
        }

        String insertImageQuery = "INSERT INTO UserImage (PrivacyStatus, Picture) VALUES (?, ?)";
        String insertCandidateQuery = "INSERT INTO Candidate (UserID, UserQualificationID, UserJobID, ImageID, AppearanceID, UserReligionID, ExpID) VALUES (?, ?, ?, ?, ?, ?, ?)";
        String insertUserPackageQuery = "INSERT INTO userPackages (packageID, startdate, enddate, candidateid) VALUES (?, ?, ?, ?)";

        try (Connection con = DatabaseConnection.connect();
             PreparedStatement psImage = con.prepareStatement(insertImageQuery, Statement.RETURN_GENERATED_KEYS);
             PreparedStatement psCandidate = con.prepareStatement(insertCandidateQuery, Statement.RETURN_GENERATED_KEYS);
             PreparedStatement psUserPackage = con.prepareStatement(insertUserPackageQuery)) {

            // Start transaction
            con.setAutoCommit(false);

            // Read the image file as a byte array
            FileInputStream fis = new FileInputStream(selectedFile);
            byte[] imageBytes = fis.readAllBytes();
            fis.close();

            // Insert data into UserImage table
            psImage.setString(1, whoCanSeePicture);
            psImage.setBytes(2, imageBytes);
            psImage.executeUpdate();

            // Retrieve the generated ImageID
            ResultSet rsImage = psImage.getGeneratedKeys();
            int imageID = 0;
            if (rsImage.next()) {
                imageID = rsImage.getInt(1);
            }

            // Insert data into Candidate table
            psCandidate.setInt(1, userID);
            psCandidate.setInt(2, UserQualificationID);
            psCandidate.setInt(3, UserJobID);
            psCandidate.setInt(4, imageID);
            psCandidate.setInt(5, AppearanceID);
            psCandidate.setInt(6, UserReligionID);
            psCandidate.setInt(7, expectationID);
            psCandidate.executeUpdate();

            // Retrieve the generated CandidateID
            ResultSet rsCandidate = psCandidate.getGeneratedKeys();
            int candidateID = 0;
            if (rsCandidate.next()) {
                candidateID = rsCandidate.getInt(1);
            }

            // Prepare data for UserPackages table
            Date today = new Date(System.currentTimeMillis());
            Date endDate = new Date(today.getTime() + 30L * 24 * 60 * 60 * 1000); // 30 days from today

            psUserPackage.setInt(1, 1);  // Default PackageID = 1
            psUserPackage.setDate(2, today);
            psUserPackage.setDate(3, endDate);
            psUserPackage.setInt(4, candidateID);
            psUserPackage.executeUpdate();

            // Commit transaction
            con.commit();

            JOptionPane.showMessageDialog(this, "Successfully Registered!");
            
            this.dispose(); // Close the form
            new SignInPage();

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());

        } catch (IOException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error reading the image file.");
        }
    }
}
