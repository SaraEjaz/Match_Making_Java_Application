import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class ExpectationsForm extends JFrame {
    private JComboBox<String> genderField, motherTongueField, sectField, professionField, maritalStatusField, casteField, religiousnessField, buildField, disabilitiesField;
    private JTextField ageFromField, ageToField, heightField, incomeField, countryField; // Changed countryField to JTextField
    private int userID;
    private int AppearanceID;
    private int UserReligionID;
    private int UserQualificationID;
    private int UserJobID;
    private int expectationID;

    public ExpectationsForm(int userID, int AppearanceID, int UserReligionID, int UserQualificationID, int UserJobID) {
        this.userID = userID;
        this.AppearanceID = AppearanceID;
        this.UserReligionID = UserReligionID;
        this.UserQualificationID = UserQualificationID;
        this.UserJobID = UserJobID;
        setTitle("Expectations");
        setLayout(new GridLayout(20, 2));
        getContentPane().setBackground(new Color(128, 0, 0));

        // Gender
        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setForeground(Color.WHITE);
        add(genderLabel);
        genderField = new JComboBox<>(new String[]{"Male", "Female"});
        add(genderField);

        // Age From
        JLabel ageFromLabel = new JLabel("Age From:");
        ageFromLabel.setForeground(Color.WHITE);
        add(ageFromLabel);
        ageFromField = new JTextField();
        add(ageFromField);

        // Age To
        JLabel ageToLabel = new JLabel("Age To:");
        ageToLabel.setForeground(Color.WHITE);
        add(ageToLabel);
        ageToField = new JTextField();
        add(ageToField);

        // Country (changed to text field)
        JLabel countryLabel = new JLabel("Country:");
        countryLabel.setForeground(Color.WHITE);
        add(countryLabel);
        countryField = new JTextField(); // Replacing JComboBox with JTextField
        add(countryField);

        // Mother Tongue
        JLabel motherTongueLabel = new JLabel("Mother Tongue:");
        motherTongueLabel.setForeground(Color.WHITE);
        add(motherTongueLabel);
        motherTongueField = new JComboBox<>(new String[]{"Pushto", "Sindhi", "Balochi", "Punjabi", "English", "Urdu","Other"});
        add(motherTongueField);

        // Sect
        JLabel sectLabel = new JLabel("Sect:");
        sectLabel.setForeground(Color.WHITE);
        add(sectLabel);
        sectField = new JComboBox<>(new String[]{"Shia", "Sunni","Protestant","Catholic","Other"});
        add(sectField);

        // Profession
        JLabel professionLabel = new JLabel("Profession:");
        professionLabel.setForeground(Color.WHITE);
        add(professionLabel);
        String[] professionOptions = {
                "Software Developer", "Doctor", "Engineer", "Professor", "Scientist",
                "Business Analyst", "Lawyer", "Artist", "Entrepreneur", "Writer", "Other"
        };
        professionField = new JComboBox<>(professionOptions);
        add(professionField);

        // Marital Status
        JLabel maritalStatusLabel = new JLabel("Marital Status:");
        maritalStatusLabel.setForeground(Color.WHITE);
        add(maritalStatusLabel);
        maritalStatusField = new JComboBox<>(new String[]{"Single", "Divorced", "Widowed","Married"});
        add(maritalStatusField);

        // Height
        JLabel heightLabel = new JLabel("Height (in cm):");
        heightLabel.setForeground(Color.WHITE);
        add(heightLabel);
        heightField = new JTextField();
        add(heightField);

        // Caste
        JLabel casteLabel = new JLabel("Caste:");
        casteLabel.setForeground(Color.WHITE);
        add(casteLabel);
        casteField = new JComboBox<>(new String[]{"Syed", "Sheikh", "Rajput", "Jutt","Siddiqui", "Sheikh", "Other"});
        add(casteField);

        // Religion
        JLabel religionLabel = new JLabel("Religion:");
        religionLabel.setForeground(Color.WHITE);
        add(religionLabel);
        religiousnessField = new JComboBox<>();
        populateReligionDropdown();
        add(religiousnessField);

        // Income
        JLabel incomeLabel = new JLabel("Income (in USD):");
        incomeLabel.setForeground(Color.WHITE);
        add(incomeLabel);
        incomeField = new JTextField();
        add(incomeField);

        // Build
        JLabel buildLabel = new JLabel("Build:");
        buildLabel.setForeground(Color.WHITE);
        add(buildLabel);
        buildField = new JComboBox<>(new String[]{"Slim", "Muscular", "Chubby", "Slender", "Heavyset"});
        add(buildField);

        // Disabilities
        JLabel disabilitiesLabel = new JLabel("Disability:");
        disabilitiesLabel.setForeground(Color.WHITE);
        add(disabilitiesLabel);
        disabilitiesField = new JComboBox<>(new String[]{"None", "Physical", "Hearing Loss", "Mental Illness", "Intellectual", "Autism", "Hearing Impairment", "Speech", "Blindness"});
        add(disabilitiesField);

        JButton registerButton = new JButton("Next");
        registerButton.addActionListener(e -> insertExpectations());
        add(registerButton);

        setSize(400, 750);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    void populateReligionDropdown() {
        try (Connection con = DatabaseConnection.connect();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT ReligionType FROM Religion")) {
            while (rs.next()) {
                religiousnessField.addItem(rs.getString("ReligionType"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching religions: " + e.getMessage());
        }
    }

    private void insertExpectations() {
        String gender = (String) genderField.getSelectedItem();
        String ageFrom = ageFromField.getText();
        String ageTo = ageToField.getText();
        String country = countryField.getText(); // Retrieve country from text field
        String motherTongue = (String) motherTongueField.getSelectedItem();
        String sect = (String) sectField.getSelectedItem();
        String profession = (String) professionField.getSelectedItem();
        String maritalStatus = (String) maritalStatusField.getSelectedItem();
        String caste = (String) casteField.getSelectedItem();
        String religiousness = (String) religiousnessField.getSelectedItem();
        String build = (String) buildField.getSelectedItem();
        String disabilities = (String) disabilitiesField.getSelectedItem();

        double height = 0;
        double income = 0;

        try {
            height = Double.parseDouble(heightField.getText());
            income = Double.parseDouble(incomeField.getText());
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Please enter valid numbers for Height and Income.");
            return;
        }

        String query = "INSERT INTO Expectations (Gender, AgeFrom, AgeTo, Country, MotherTongue, Sect, Profession, MaritalStatus, Height, Caste, Religion, MonthlyIncome, Build, Disability) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DatabaseConnection.connect();
             PreparedStatement ps = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, gender);
            ps.setInt(2, Integer.parseInt(ageFrom));
            ps.setInt(3, Integer.parseInt(ageTo));
            ps.setString(4, country);
            ps.setString(5, motherTongue);
            ps.setString(6, sect);
            ps.setString(7, profession);
            ps.setString(8, maritalStatus);
            ps.setDouble(9, height);
            ps.setString(10, caste);
            ps.setString(11, religiousness);
            ps.setDouble(12, income);
            ps.setString(13, build);
            ps.setString(14, disabilities);

            int rowsAffected = ps.executeUpdate();
            if (rowsAffected > 0) {
                try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        expectationID = generatedKeys.getInt(1);
                    }
                }
            }

            JOptionPane.showMessageDialog(this, "Expectations registered successfully!");
            this.dispose();
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }

        new ImagePrivacyForm(userID, AppearanceID, UserReligionID, UserQualificationID, UserJobID, expectationID).setVisible(true);
        this.dispose();
    }

    public static void main(String[] args) {
        new ExpectationsForm(1, 1, 1, 1, 1);
    }
}
