import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.math.BigDecimal;
import java.sql.*;
import javax.swing.border.TitledBorder;

public class SearchByCareerInfo extends JFrame {
    private JPanel mainPanel, resultsPanel, careerPanel;
    private JComboBox<String> qualificationDropdown, professionDropdown, incomeDropdown;
    private JButton searchButton;
    String username;
    int candidateId;
    public SearchByCareerInfo(String username,int candidateId) {
        setTitle("Search Page");
        setSize(1200, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
 this.username=username;
            this.candidateId=candidateId;
        // Menu Panel (left side)
        JPanel menuPanel = new JPanel();
        menuPanel.setBackground(new Color(128, 0, 0)); // Maroon background
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
        String[] menuOptions = {};
        for (String option : menuOptions) {
            JButton button = new JButton(option);
            button.setAlignmentX(Component.CENTER_ALIGNMENT);
            button.setFont(new Font("Arial", Font.BOLD, 14));
            button.setBackground(Color.WHITE);
            button.setForeground(new Color(128, 0, 0)); // Maroon text
            button.setFocusPainted(false);
            button.setBorderPainted(false);
            // Action listener to show the corresponding panel when button is clicked
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (option.equals("Career Info")) {
                        toggleCareerPanel();
                    }
                }
            });
            menuPanel.add(button);
        }
        add(menuPanel, BorderLayout.WEST);

        // Main Panel (right side where the forms will appear)
        mainPanel = new JPanel();
        mainPanel.setLayout(new BorderLayout());
        add(mainPanel, BorderLayout.CENTER);

        // Career Info Panel (fields for search)
        createCareerInfoPanel();

        // Results Panel (where search results will appear)
        resultsPanel = new JPanel();
        resultsPanel.setLayout(new BoxLayout(resultsPanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(resultsPanel);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
    }

    private void toggleCareerPanel() {
        // Toggle the visibility of the Career Info panel
        if (careerPanel != null) {
            careerPanel.setVisible(!careerPanel.isVisible());
        }
    }
private void createCareerInfoPanel() { 
    if (careerPanel == null) {
        careerPanel = new JPanel();
        careerPanel.setLayout(new GridLayout(0, 2, 10, 10));
        careerPanel.setBorder(BorderFactory.createTitledBorder("Quick Search"));
        TitledBorder titledBorder = BorderFactory.createTitledBorder("Search By Career Info");
        titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 22));  // Make the title bold
        titledBorder.setTitleColor(Color.WHITE); // Set the title font color to white
        titledBorder.setBorder(BorderFactory.createLineBorder(Color.white, 2)); // Set the border color to black
        careerPanel.setBorder(titledBorder);

        // Set the background color of the panel to black for contrast
        careerPanel.setBackground(Color.BLACK);

        // Qualification Dropdown
        JLabel qualificationLabel = new JLabel("Qualification:");
        qualificationLabel.setForeground(Color.WHITE); // Set label font color to white
        careerPanel.add(qualificationLabel);
        
        qualificationDropdown = new JComboBox<>(getQualifications());
        careerPanel.add(qualificationDropdown);

        // Profession Dropdown
        JLabel professionLabel = new JLabel("Profession:");
        professionLabel.setForeground(Color.WHITE); // Set label font color to white
        careerPanel.add(professionLabel);
        String[] professions = {
            "Software Developer", "Doctor", "Engineer", "Professor", "Scientist",
            "Business Analyst", "Lawyer", "Artist", "Entrepreneur", "Writer", "Other"
        };
        professionDropdown = new JComboBox<>(professions);
        careerPanel.add(professionDropdown);

        // Monthly Income Range
        JLabel incomeLabel = new JLabel("Monthly Income (From - To):");
        incomeLabel.setForeground(Color.WHITE);
        careerPanel.add(incomeLabel);

        JPanel incomePanel = new JPanel();
        incomePanel.setLayout(new FlowLayout());
        
        JTextField incomeFromField = new JTextField(10); // Field for "From" income
        JTextField incomeToField = new JTextField(10); // Field for "To" income
        
        incomePanel.add(new JLabel("From:"));
        incomePanel.add(incomeFromField);
        incomePanel.add(new JLabel("To:"));
        incomePanel.add(incomeToField);
        
        careerPanel.add(incomePanel);

        // Search Button
        searchButton = new JButton("Search");
        searchButton.addActionListener(e -> performSearch(incomeFromField, incomeToField)); // Pass the fields
        careerPanel.add(searchButton);

        // Add the Back Button
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            // Assuming you have a WelcomePage constructor that takes the necessary parameters
            new WelcomePage(username, candidateId).setVisible(true); // Navigate back to WelcomePage
            dispose(); // Close current page
        });
        careerPanel.add(backButton);

        mainPanel.add(careerPanel, BorderLayout.NORTH); // Add the careerPanel at the top of the mainPanel
    }
    careerPanel.setVisible(true);
}

 // Fetch qualifications from the database
    private String[] getQualifications() {
        try (Connection con = DatabaseConnection.connect();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT QualificationType FROM Qualification")) {
            return rsToArray(rs);
        } catch (SQLException e) {
            e.printStackTrace();
            return new String[]{"Error loading qualifications"};
        }
    }
     // Helper method to convert ResultSet to String array
    private String[] rsToArray(ResultSet rs) throws SQLException {
        java.util.List<String> list = new java.util.ArrayList<>();
        while (rs.next()) {
            list.add(rs.getString(1));
        }
        return list.toArray(new String[0]);
    }

private void performSearch(JTextField incomeFromField, JTextField incomeToField) {
    resultsPanel.removeAll(); // Clear previous results
    resultsPanel.revalidate();
    resultsPanel.repaint();

    // Debugging: Print the selected criteria
    System.out.println("Searching with:");
    System.out.println("Qualification: " + qualificationDropdown.getSelectedItem());
    System.out.println("Profession: " + professionDropdown.getSelectedItem());
    System.out.println("Income From: " + incomeFromField.getText());
    System.out.println("Income To: " + incomeToField.getText());

    try (Connection connection = DatabaseConnection.connect()) {
        String query = buildQuery(incomeFromField, incomeToField); // Pass the text fields to buildQuery
        System.out.println("Executing Query: " + query); // Log the query for debugging
        PreparedStatement statement = connection.prepareStatement(query);

        // Set parameters for the query
        int paramIndex = 1;
        if (qualificationDropdown != null) {
            statement.setString(paramIndex++, qualificationDropdown.getSelectedItem().toString());
        }
        if (professionDropdown != null) {
            statement.setString(paramIndex++, professionDropdown.getSelectedItem().toString());
        }
        if (incomeFromField != null && !incomeFromField.getText().isEmpty()) {
            statement.setBigDecimal(paramIndex++, new BigDecimal(incomeFromField.getText())); // From income
        }
        if (incomeToField != null && !incomeToField.getText().isEmpty()) {
            statement.setBigDecimal(paramIndex++, new BigDecimal(incomeToField.getText())); // To income
        }

        // Execute query and process results
        ResultSet rs = statement.executeQuery();
        boolean hasResults = false;

        // Set GridLayout for resultsPanel to show 3 profiles per row
        resultsPanel.setLayout(new GridLayout(0, 3, 10, 10));  // 0 rows (dynamic), 3 columns, 10px gap

        while (rs.next()) {
            hasResults = true;
            int userId = rs.getInt("UserID");
            String privacyStatus = rs.getString("PrivacyStatus");

            JPanel profilePanel = new JPanel();
            profilePanel.setLayout(new BorderLayout());
            profilePanel.setBackground(new Color(128, 0, 0));  // Maroon background
            profilePanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));

            // Profile image or placeholder
            JLabel imageLabel;
            if (privacyStatus != null && !privacyStatus.equalsIgnoreCase("Only Me")) {
                byte[] imageBytes = rs.getBytes("ProfileImage");
                if (imageBytes != null) {
                    ImageIcon profileImage = new ImageIcon(imageBytes);

                    // Resize the image to a smaller size (e.g., 100x100)
                    Image img = profileImage.getImage();  // Image from ImageIcon
                    Image scaledImg = img.getScaledInstance(100, 100, Image.SCALE_SMOOTH); // Scale image to fit
                    ImageIcon scaledIcon = new ImageIcon(scaledImg);

                    imageLabel = new JLabel(scaledIcon);
                } else {
                    imageLabel = new JLabel("No image available.");
                }
            } else {
                imageLabel = new JLabel("Image hidden due to privacy settings.");
            }

            profilePanel.add(imageLabel, BorderLayout.NORTH);

            // Add Profile Information
            JPanel infoPanel = new JPanel();
            infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
            infoPanel.setBackground(new Color(128, 0, 0));  // Maroon background

            JLabel nameLabel = new JLabel("Name: " + rs.getString("FirstName") + " " + rs.getString("LastName"));
            nameLabel.setForeground(Color.WHITE);  // White font
            infoPanel.add(nameLabel);

            JLabel qualificationLabel = new JLabel("Qualification: " + rs.getString("QualificationType"));
            qualificationLabel.setForeground(Color.WHITE);  // White font
            infoPanel.add(qualificationLabel);

            JLabel professionLabel = new JLabel("Profession: " + rs.getString("QualificationProfession"));
            professionLabel.setForeground(Color.WHITE);  // White font
            infoPanel.add(professionLabel);

            JLabel incomeLabel = new JLabel("Income: " + rs.getString("MonthlyIncome"));
            incomeLabel.setForeground(Color.WHITE);  // White font
            infoPanel.add(incomeLabel);

            // View Profile Button
            JButton viewProfileButton = new JButton("View Profile");
            viewProfileButton.setForeground(Color.WHITE);  // White font on button
            viewProfileButton.setBackground(new Color(128, 0, 0));  // Maroon background for button
            viewProfileButton.addActionListener(e -> {
                System.out.println("View Profile button clicked for UserID: " + userId);
                showProfileDetails(userId);
            });
            infoPanel.add(viewProfileButton);

            // Chat Button
            JButton chatButton = new JButton("Chat");
            chatButton.setForeground(Color.WHITE);  // White font on button
            chatButton.setBackground(new Color(128, 0, 0));  // Maroon background for button
            chatButton.addActionListener(e -> {
                System.out.println("Chat button clicked for UserID: " + userId);
                openChatWindow(userId);
            });
            infoPanel.add(chatButton);

            profilePanel.add(infoPanel, BorderLayout.CENTER);
            resultsPanel.add(profilePanel);
        }

        // If no results are found
        if (!hasResults) {
            JLabel noResultsLabel = new JLabel("No results found.");
            noResultsLabel.setForeground(Color.WHITE);  // White font for the "No results" label
            resultsPanel.add(noResultsLabel);
        }

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error retrieving profiles: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}


 private void openChatWindow(int receiverId) {
    try (Connection connection = DatabaseConnection.connect()) {
        // Get the candidate's packageID and subscription end date
        String packageQuery = "SELECT packageid, enddate FROM userPackages WHERE candidateid = ?";
        PreparedStatement packageStatement = connection.prepareStatement(packageQuery);
        packageStatement.setInt(1, candidateId);
        ResultSet packageResult = packageStatement.executeQuery();

        boolean hasValidPackage1 = false; // Flag to check if package ID 1 is valid
        boolean hasValidPackage2 = false; // Flag to check if package ID 2 is valid

        // Loop through all the packages of the candidate
        while (packageResult.next()) {
            int packageId = packageResult.getInt("packageid");
            Date endDate = packageResult.getDate("enddate");

            // Check if packageID 1 is valid (not expired)
            if (packageId == 1 && endDate != null && endDate.after(new java.util.Date())) {
                hasValidPackage1 = true; // Package 1 is valid
            }

            // Check if packageID 2 is valid (not expired)
            if (packageId == 2 && endDate != null && endDate.after(new java.util.Date())) {
                hasValidPackage2 = true; // Package 2 is valid
            }
        }

        // If no valid package (either 1 or 2) found
        if (!hasValidPackage1 && !hasValidPackage2) {
            JOptionPane.showMessageDialog(this, "Your subscription has expired or you don't have an active package. Please renew it to chat.", "Subscription Expired", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // If packageId 2 is valid, chat with everyone (no verification check)
        if (hasValidPackage2) {
            // Open chat window for all users, no verification check required
            Chat chatWindow = new Chat(username, receiverId);
            chatWindow.setVisible(true);
        } else if (hasValidPackage1) {
            // If packageId 1 is valid, check if the receiver is verified
            String verificationQuery = "SELECT isVerified FROM [user] WHERE userID = ?";
            PreparedStatement verificationStatement = connection.prepareStatement(verificationQuery);
            verificationStatement.setInt(1, receiverId);
            ResultSet verificationResult = verificationStatement.executeQuery();

            if (verificationResult.next()) {
                String isVerified = verificationResult.getString("isVerified");

                // If the receiver is verified, show message and don't allow chat
                if (isVerified.equalsIgnoreCase("Yes")) {
                    JOptionPane.showMessageDialog(this, "You can only chat with unverified users with your current package.", "Verification Required", JOptionPane.WARNING_MESSAGE);
                } else {
                    // If the receiver is not verified, allow chat
                    Chat chatWindow = new Chat(username, receiverId);
                    chatWindow.setVisible(true);
                }
            }
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error retrieving subscription or verification details: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

private String buildQuery(JTextField incomeFromField, JTextField incomeToField) {
    StringBuilder query = new StringBuilder("SELECT * FROM UserProfileView WHERE 1=1 ");

    // Career Info filters
    if (qualificationDropdown != null) {
        query.append("AND QualificationType = ? ");
    }
    if (professionDropdown != null) {
        query.append("AND QualificationProfession = ? ");
    }
    if (incomeFromField != null && !incomeFromField.getText().isEmpty() && incomeToField != null && !incomeToField.getText().isEmpty()) {
        query.append("AND MonthlyIncome BETWEEN ? AND ? ");
    } else if (incomeFromField != null && !incomeFromField.getText().isEmpty()) {
        query.append("AND MonthlyIncome >= ? ");
    } else if (incomeToField != null && !incomeToField.getText().isEmpty()) {
        query.append("AND MonthlyIncome <= ? ");
    }

    return query.toString();
}

private void showProfileDetails(int userId) {
    try (Connection connection = DatabaseConnection.connect()) {
        String query = "SELECT * FROM UserProfileView WHERE UserID = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, userId);
        ResultSet rs = statement.executeQuery();

        if (rs.next()) {
            JFrame profileFrame = new JFrame("Profile Details");
            profileFrame.setSize(1000, 600);
            profileFrame.setLayout(new BorderLayout());
            profileFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            // Create a panel for profile image and other details
            JPanel profileDetailsPanel = new JPanel();
            profileDetailsPanel.setLayout(new BorderLayout());
            profileDetailsPanel.setBackground(Color.BLACK);  // Set the background of the image panel to black

            // Check PrivacyStatus before displaying the profile image
            String privacyStatus = rs.getString("PrivacyStatus");

            JLabel imageLabel;
            if (privacyStatus != null && !privacyStatus.equalsIgnoreCase("Only Me")) {
                byte[] imageBytes = rs.getBytes("ProfileImage");
                if (imageBytes != null) {
                    ImageIcon profileImage = new ImageIcon(imageBytes);
                    Image img = profileImage.getImage();  // Image from ImageIcon
                    Image scaledImg = img.getScaledInstance(200, 200, Image.SCALE_SMOOTH); // Scale image to fit
                    ImageIcon scaledIcon = new ImageIcon(scaledImg);

                    imageLabel = new JLabel(scaledIcon);
                    imageLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
                } else {
                    imageLabel = new JLabel("No profile picture available.");
                    imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
                }
            } else {
                imageLabel = new JLabel("Profile picture hidden due to privacy settings.");
                imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
            }

            profileDetailsPanel.add(imageLabel, BorderLayout.WEST);

            // Create the personal information panel with a distinct background color
            JPanel personalInfoPanel = new JPanel();
            personalInfoPanel.setLayout(new BoxLayout(personalInfoPanel, BoxLayout.Y_AXIS));
            personalInfoPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2), 
                "Personal Info",
                TitledBorder.CENTER,
                TitledBorder.TOP,
                new Font("Serif", Font.BOLD, 16), 
                Color.WHITE
            ));
            personalInfoPanel.setBackground(new Color(128, 0, 0));  // Dark red background
            personalInfoPanel.setForeground(Color.WHITE);  // Set the text color to white
           personalInfoPanel.add(createLabel("Name: " + rs.getString("FirstName") + " " + rs.getString("LastName")));
            personalInfoPanel.add(createLabel("Gender: " + rs.getString("Gender")));
            personalInfoPanel.add(createLabel("Age: " + (2024 - rs.getDate("DateOfBirth").toLocalDate().getYear())));
            personalInfoPanel.add(createLabel("Country: " + rs.getString("Country")));
            personalInfoPanel.add(createLabel("City: " + rs.getString("City")));
            personalInfoPanel.add(createLabel("Marital Status: " + rs.getString("MaritalStatus")));
            personalInfoPanel.add(createLabel("Religion: " + rs.getString("Religion")));
            personalInfoPanel.add(createLabel("Sect: " + rs.getString("Sect")));
            personalInfoPanel.add(createLabel("Mother Tongue: " + rs.getString("MotherTongue")));
            personalInfoPanel.add(createLabel("Caste: " + rs.getString("Caste")));
            personalInfoPanel.add(createLabel("Disability: " + rs.getString("Disability")));
            personalInfoPanel.add(createLabel("Height: " + rs.getString("Height")));
            personalInfoPanel.add(createLabel("Smoke: " + rs.getString("Smoke")));
            personalInfoPanel.add(createLabel("Complexion: " + rs.getString("Complexion")));
            personalInfoPanel.add(createLabel("Hair Color: " + rs.getString("HairColor")));
            personalInfoPanel.add(createLabel("Weight: " + rs.getString("Weight")));
            personalInfoPanel.add(createLabel("Build: " + rs.getString("Build")));
            personalInfoPanel.add(createLabel("Eye Color: " + rs.getString("EyeColor")));
            // Career Info Panel
            JPanel careerInfoPanel = new JPanel();
            careerInfoPanel.setLayout(new BoxLayout(careerInfoPanel, BoxLayout.Y_AXIS));
            careerInfoPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2), 
                "Career Info",
                TitledBorder.CENTER,
                TitledBorder.TOP,
                new Font("Serif", Font.BOLD, 16), 
                Color.WHITE
            ));
            careerInfoPanel.setBackground(new Color(128, 0, 0));
            careerInfoPanel.setForeground(Color.WHITE);  // Set text color to white
         careerInfoPanel.add(createLabel("Qualification: " + rs.getString("QualificationType")));
            careerInfoPanel.add(createLabel("Profession: " + rs.getString("QualificationProfession")));
            careerInfoPanel.add(createLabel("Monthly Income: " + rs.getString("MonthlyIncome")));
            careerInfoPanel.add(createLabel("Job Post: " + rs.getString("JobName")));
            careerInfoPanel.add(createLabel("University: " + rs.getString("University")));
            careerInfoPanel.add(createLabel("Major course: " + rs.getString("MajorCourse")));
            careerInfoPanel.add(createLabel("Future Plan: " + rs.getString("FuturePlan")));

            // Expectations Panel
            JPanel expectationsPanel = new JPanel();
            expectationsPanel.setLayout(new BoxLayout(expectationsPanel, BoxLayout.Y_AXIS));
            expectationsPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2), 
                "Expectations",
                TitledBorder.CENTER,
                TitledBorder.TOP,
                new Font("Serif", Font.BOLD, 16), 
                Color.WHITE
            ));
            expectationsPanel.setBackground(new Color(128, 0, 0));
            expectationsPanel.setForeground(Color.WHITE);  // Set text color to white
              expectationsPanel.add(createLabel("Expected Gender: " + rs.getString("ExpectationGender")));
            expectationsPanel.add(createLabel("Expected Age: " + rs.getString("ExpectationAgeFrom") + " - " + rs.getString("ExpectationAgeTo")));
            expectationsPanel.add(createLabel("Expected Country: " + rs.getString("ExpectationCountry")));
            expectationsPanel.add(createLabel("Expected Profession: " + rs.getString("ExpectationProfession")));
            expectationsPanel.add(createLabel("Expected Marital Status: " + rs.getString("ExpectationMaritalStatus")));
            expectationsPanel.add(createLabel("Expected Height: " + rs.getString("ExpectationHeight")));
            expectationsPanel.add(createLabel("Expected Caste: " + rs.getString("ExpectationCaste")));
            expectationsPanel.add(createLabel("Expected Disability: " + rs.getString("ExpectationDisability")));
            expectationsPanel.add(createLabel("Expected Build: " + rs.getString("ExpectationBuild")));
            expectationsPanel.add(createLabel("Expected Religion: " + rs.getString("ExpectationReligion")));
            expectationsPanel.add(createLabel("Expected Monthly Income: " + rs.getString("ExpectationMonthlyIncome")));

            // Create a scrollable container for all the panels
            JPanel rightPanel = new JPanel();
            rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS)); // Stack vertically
            rightPanel.add(personalInfoPanel);
            rightPanel.add(careerInfoPanel);
            rightPanel.add(expectationsPanel);

            // Wrap everything inside a JScrollPane
            JScrollPane scrollPane = new JScrollPane(rightPanel);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

            profileFrame.add(profileDetailsPanel, BorderLayout.WEST);
            profileFrame.add(scrollPane, BorderLayout.CENTER);

            SwingUtilities.invokeLater(() -> profileFrame.setVisible(true));
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error retrieving profile details: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

// Helper method to create labels with white font color
private JLabel createLabel(String text) {
    JLabel label = new JLabel(text);
    label.setForeground(Color.WHITE);  // Set the label text to white
    return label;
}


    public static void main(String[] args) {
       
    }
}
