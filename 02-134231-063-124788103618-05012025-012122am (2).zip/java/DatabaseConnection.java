import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;

public class DatabaseConnection {
    public static Connection connect() {
        try {
             String url = "jdbc:sqlserver://localhost:1433;databaseName=PROJECT;encrypt=true;trustServerCertificate=true;";
        String user = "admin";
        String password = "12345";
            return DriverManager.getConnection(url,user,password);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}