//check the packageid of canddateid n userpackage table, if packageid is 1 then allow candidate id to chat only with those users which has isVerified status yes and if packageid is 2 then allow chatting with everyone, also check the enddate(it should be less than current date) 


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.border.TitledBorder;


public class SearchPage extends JFrame {
     private JPanel mainPanel, resultsPanel, careerPanel;
     private JTextField countryTextField;
    private JComboBox<String> countryDropdown,  cityDropdown;
    private JSpinner ageFromSpinner, ageToSpinner;
    private JCheckBox maleCheckBox, femaleCheckBox, featuredCheckBox, verifiedCheckBox;
    private JButton searchButton, viewProfileButton;
    private JComboBox<String> qualificationDropdown, professionDropdown, incomeDropdown;
    String username;
    int candidateId;
        public SearchPage( String username,int candidateId) {
            this.username=username;
            this.candidateId=candidateId;
        setTitle("Search Page");
        setSize(1200, 800);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout());// Menu Panel
        JPanel menuPanel = new JPanel();
        menuPanel.setBackground(new Color(128, 0, 0)); // Maroon background
        menuPanel.setLayout(new BoxLayout(menuPanel, BoxLayout.Y_AXIS));
String[] menuOptions = {};
        for (String option : menuOptions) {
            JButton button = new JButton(option);
            button.setAlignmentX(Component.CENTER_ALIGNMENT);
            button.setFont(new Font("Arial", Font.BOLD, 14));
            button.setBackground(new Color(255, 255, 255)); // White font
            button.setForeground(new Color(128, 0, 0)); // Maroon text
            button.setFocusPainted(false);
            button.setBorderPainted(false);
       // Action listener to show the corresponding panel when button is clicked
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    if (option.equals("Career Info")) {
                        toggleCareerPanel();
                    }
                }
            });
            menuPanel.add(button);
        }
        add(menuPanel, BorderLayout.WEST);// Main Panel
        mainPanel = new JPanel(new BorderLayout());
        add(mainPanel, BorderLayout.CENTER);
// Quick Search Panel
        createQuickSearchPanel();
// Results Panel
        resultsPanel = new JPanel();
        resultsPanel.setLayout(new BoxLayout(resultsPanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(resultsPanel);
        mainPanel.add(scrollPane, BorderLayout.CENTER);
        resultsPanel = new JPanel();
resultsPanel.setLayout(new BoxLayout(resultsPanel, BoxLayout.Y_AXIS));
 scrollPane = new JScrollPane(resultsPanel);
scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); // Enable vertical scrollbar
mainPanel.add(scrollPane, BorderLayout.CENTER);

    }
         private void toggleCareerPanel() {
        if (careerPanel != null) {
            careerPanel.setVisible(!careerPanel.isVisible());
        }
    }
         private void createQuickSearchPanel() {
    JPanel quickSearchPanel = new JPanel();
    quickSearchPanel.setLayout(new GridLayout(0, 2, 10, 10));
    quickSearchPanel.setBorder(BorderFactory.createTitledBorder("Quick Search"));
    TitledBorder titledBorder = BorderFactory.createTitledBorder("Quick Search");
    titledBorder.setTitleFont(new Font("Arial", Font.BOLD, 22));  // Make the title bold
    titledBorder.setTitleColor(Color.WHITE); // Set the title font color to white
    titledBorder.setBorder(BorderFactory.createLineBorder(Color.white, 2)); // Set the border color to black
    quickSearchPanel.setBorder(titledBorder);

    // Set the background color of the panel to black for contrast
    quickSearchPanel.setBackground(Color.BLACK);

    // Gender Checkboxes
    JLabel genderLabel = new JLabel("Gender:");
    genderLabel.setForeground(Color.WHITE); // White font
    quickSearchPanel.add(genderLabel);

    // Gender Checkboxes
    JPanel genderPanel = new JPanel();
    genderPanel.setLayout(new FlowLayout());
    maleCheckBox = new JCheckBox("Male");
    femaleCheckBox = new JCheckBox("Female");
    genderPanel.add(maleCheckBox);
    genderPanel.add(femaleCheckBox);
    quickSearchPanel.add(genderPanel);

 
   

    // Age Range
    JLabel ageFromLabel = new JLabel("Age From:");
    ageFromLabel.setForeground(Color.WHITE); // White font
    quickSearchPanel.add(ageFromLabel);
    ageFromSpinner = new JSpinner(new SpinnerNumberModel(18, 18, 99, 1));
    quickSearchPanel.add(ageFromSpinner);

    JLabel ageToLabel = new JLabel("Age To:");
    ageToLabel.setForeground(Color.WHITE); // White font
    quickSearchPanel.add(ageToLabel);
    ageToSpinner = new JSpinner(new SpinnerNumberModel(18, 18, 99, 1));
    quickSearchPanel.add(ageToSpinner);
 JLabel countryLabel = new JLabel("Country:");
    countryLabel.setForeground(Color.WHITE); // White font
    quickSearchPanel.add(countryLabel);
    countryTextField = new JTextField();
quickSearchPanel.add(countryTextField);


    // Search Button
    searchButton = new JButton("Search");
    searchButton.addActionListener(e -> performSearch());
    quickSearchPanel.add(searchButton);
 // Add the Back Button
        JButton backButton = new JButton("Back");
        backButton.addActionListener(e -> {
            // Assuming you have a WelcomePage constructor that takes the necessary parameters
            new WelcomePage(username, candidateId).setVisible(true); // Navigate back to WelcomePage
            dispose(); // Close current page
        });
        quickSearchPanel.add(backButton);
    // Add the panel to the main layout
    mainPanel.add(quickSearchPanel, BorderLayout.NORTH);
}
private void performSearch() {
    resultsPanel.removeAll(); // Clear previous results
    resultsPanel.revalidate();
    resultsPanel.repaint();

    try (Connection connection = DatabaseConnection.connect()) {
        String query = buildQuery(); // Get query from the buildQuery() method
        PreparedStatement statement = connection.prepareStatement(query);

        // Set parameters
        int paramIndex = 1;

        // Gender filter
        if (maleCheckBox.isSelected() || femaleCheckBox.isSelected()) {
            if (maleCheckBox.isSelected()) statement.setString(paramIndex++, "Male");
            if (femaleCheckBox.isSelected()) statement.setString(paramIndex++, "Female");
        }

        

        // Age range
        statement.setInt(paramIndex++, (int) ageFromSpinner.getValue());
        statement.setInt(paramIndex++, (int) ageToSpinner.getValue());

        // Country filter (from text field)
        String country = countryTextField.getText().trim();
        if (!country.isEmpty()) {
            statement.setString(paramIndex++, country);
        }

        // Execute query
        ResultSet rs = statement.executeQuery();
        boolean hasResults = false;

        // Set GridLayout for 3 profiles per row
        resultsPanel.setLayout(new GridLayout(0, 3, 10, 10)); // 0 means as many rows as needed, 3 columns

        while (rs.next()) {
            hasResults = true;
            int userId = rs.getInt("UserID");
            byte[] profileImageBytes = rs.getBytes("ProfileImage");

            JPanel profilePanel = new JPanel();
            profilePanel.setLayout(new BorderLayout());
            profilePanel.setBorder(BorderFactory.createLineBorder(Color.GRAY));
            profilePanel.setBackground(new Color(128, 0, 0));  // Maroon background color

            // Profile info panel
            JPanel infoPanel = new JPanel();
            infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
            infoPanel.setBackground(new Color(128, 0, 0));  // Maroon background for infoPanel
            JLabel nameLabel = new JLabel("Name: " + rs.getString("FirstName") + " " + rs.getString("LastName"));
            nameLabel.setForeground(Color.WHITE);  // Set font color to white
            infoPanel.add(nameLabel);

            JLabel ageLabel = new JLabel("Age: " + (2024 - rs.getDate("DateOfBirth").toLocalDate().getYear()));
            ageLabel.setForeground(Color.WHITE);  // Set font color to white
            infoPanel.add(ageLabel);

            JLabel motherTongueLabel = new JLabel("Mother Tongue: " + rs.getString("MotherTongue"));
            motherTongueLabel.setForeground(Color.WHITE);  // Set font color to white
            infoPanel.add(motherTongueLabel);

            JLabel maritalStatusLabel = new JLabel("Marital Status: " + rs.getString("MaritalStatus"));
            maritalStatusLabel.setForeground(Color.WHITE);  // Set font color to white
            infoPanel.add(maritalStatusLabel);

            JLabel verifiedLabel = new JLabel("Verified: " + rs.getString("IsVerified"));
            verifiedLabel.setForeground(Color.WHITE);  // Set font color to white
            infoPanel.add(verifiedLabel);

            // View Profile Button
            JButton viewProfileButton = new JButton("View Profile");
            viewProfileButton.addActionListener(e -> {
                System.out.println("View Profile button clicked for UserID: " + userId);
                showProfileDetails(userId);
            });
            infoPanel.add(viewProfileButton);

            // Chat Button
            JButton chatButton = new JButton("Chat");
            chatButton.addActionListener(e -> {
                System.out.println("Chat button clicked for UserID: " + userId);
                openChatWindow(userId);
            });
            infoPanel.add(chatButton);

            // Profile image panel (conditionally hidden)
            JPanel imagePanel = new JPanel();
            imagePanel.setBackground(new Color(128, 0, 0));  
            JLabel imageLabel = new JLabel();

            // Fetch image or set a placeholder if "me" status
            String imageStatus = rs.getString("PrivacyStatus"); // Assuming "ImageStatus" field exists
            if ("Everyone".equals(imageStatus)) {
                if (profileImageBytes != null && profileImageBytes.length > 0) {
                    // Create an ImageIcon from the byte array
                    ImageIcon imageIcon = new ImageIcon(profileImageBytes);

                    // Resize the image to fit a smaller size (e.g., 50x50)
                    Image img = imageIcon.getImage();
                    Image scaledImg = img.getScaledInstance(150, 150, Image.SCALE_SMOOTH);

                    // Create a new ImageIcon with the scaled image
                    imageLabel.setIcon(new ImageIcon(scaledImg));
                } else {
                    imageLabel.setText("No Image Available");
                }
            } else {
                imageLabel.setText("Image Hidden Due to Privacy");
            }

            imagePanel.add(imageLabel);
            profilePanel.add(imagePanel, BorderLayout.NORTH);
            profilePanel.add(infoPanel, BorderLayout.CENTER);

            resultsPanel.add(profilePanel);
        }

        // If no results are found
        if (!hasResults) {
            resultsPanel.add(new JLabel("No results found."));
        }

    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error retrieving profiles: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

   


 private void openChatWindow(int receiverId) {
    try (Connection connection = DatabaseConnection.connect()) {
        // Get the candidate's packageID and subscription end date
        String packageQuery = "SELECT packageid, enddate FROM userPackages WHERE candidateid = ?";
        PreparedStatement packageStatement = connection.prepareStatement(packageQuery);
        packageStatement.setInt(1, candidateId);  // This is the current user (the candidate)
        ResultSet packageResult = packageStatement.executeQuery();

        boolean hasValidPackage1 = false; // Flag to check if package ID 1 is valid
        boolean hasValidPackage2 = false; // Flag to check if package ID 2 is valid

        // Loop through all the packages of the candidate
        while (packageResult.next()) {
            int packageId = packageResult.getInt("packageid");
            Date endDate = packageResult.getDate("enddate");

            // Check if packageID 1 is valid (not expired)
            if (packageId == 1 && endDate != null && endDate.after(new java.util.Date())) {
                hasValidPackage1 = true; // Package 1 is valid
            }

            // Check if packageID 2 is valid (not expired)
            if (packageId == 2 && endDate != null && endDate.after(new java.util.Date())) {
                hasValidPackage2 = true; // Package 2 is valid
            }
        }

        // If no valid package (either 1 or 2) found
        if (!hasValidPackage1 && !hasValidPackage2) {
            JOptionPane.showMessageDialog(this, "Your subscription has expired or you don't have an active package. Please renew it to chat.", "Subscription Expired", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // If packageId 2 is valid, chat with everyone (no verification check)
        if (hasValidPackage2) {
            // Open chat window for all users, no verification check required
            Chat chatWindow = new Chat(username, receiverId); // receiverId is the user you're chatting with
            chatWindow.setVisible(true);
        } else if (hasValidPackage1) {
            // If packageId 1 is valid, check if the receiver is verified
            String verificationQuery = "SELECT isVerified FROM [user] WHERE userID = ?";
            PreparedStatement verificationStatement = connection.prepareStatement(verificationQuery);
            verificationStatement.setInt(1, receiverId); // Receiver's userId (who you're chatting with)
            ResultSet verificationResult = verificationStatement.executeQuery();

            if (verificationResult.next()) {
                String isVerified = verificationResult.getString("isVerified");

                // If the receiver is verified, show message and don't allow chat
                if (isVerified.equalsIgnoreCase("Yes")) {
                    JOptionPane.showMessageDialog(this, "You can only chat with unverified users with your current package.", "Verification Required", JOptionPane.WARNING_MESSAGE);
                } else {
                    // If the receiver is not verified, allow chat
                    Chat chatWindow = new Chat(username, receiverId);
                    chatWindow.setVisible(true);
                }
            }
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error retrieving subscription or verification details: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}


           
private void showProfileDetails(int userId) {
    try (Connection connection = DatabaseConnection.connect()) {
        String query = "SELECT * FROM UserProfileView WHERE UserID = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, userId);
        ResultSet rs = statement.executeQuery();

        if (rs.next()) {
            JFrame profileFrame = new JFrame("Profile Details");
            profileFrame.setSize(1000, 600);
            profileFrame.setLayout(new BorderLayout());
            profileFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            // Create a panel for profile image and other details
            profileFrame.getContentPane().setBackground(Color.BLACK);
            profileFrame.setBackground(new Color(128, 0, 0));
            JPanel profileDetailsPanel = new JPanel();
            profileDetailsPanel.setLayout(new BorderLayout());
            profileDetailsPanel.setBackground(Color.BLACK);

            // Check PrivacyStatus before displaying the profile image
            String privacyStatus = rs.getString("PrivacyStatus");

            JLabel imageLabel;
            if (privacyStatus != null && !privacyStatus.equalsIgnoreCase("Only Me")) {
                byte[] imageBytes = rs.getBytes("ProfileImage");
                if (imageBytes != null) {
                    ImageIcon profileImage = new ImageIcon(imageBytes);

                    // Resize the image to a smaller size (e.g., 200x200)
                    Image img = profileImage.getImage();  // Image from ImageIcon
                    Image scaledImg = img.getScaledInstance(200, 200, Image.SCALE_SMOOTH); // Scale image to fit
                    ImageIcon scaledIcon = new ImageIcon(scaledImg);

                    imageLabel = new JLabel(scaledIcon);
                    imageLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
                } else {
                    imageLabel = new JLabel("No profile picture available.");
                    imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
                }
            } else {
                imageLabel = new JLabel("Profile picture hidden due to privacy settings.");
                imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
            }

            profileDetailsPanel.add(imageLabel, BorderLayout.WEST);

            // Create the personal information panel with a distinct background color
            JPanel personalInfoPanel = new JPanel();
            personalInfoPanel.setLayout(new BoxLayout(personalInfoPanel, BoxLayout.Y_AXIS));
            personalInfoPanel.setBackground(new Color(128, 0, 0)); // Maroon background
            personalInfoPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2),
                "Personal Info",
                TitledBorder.LEFT, TitledBorder.TOP,
                new Font("Serif", Font.BOLD, 16), Color.WHITE));  // Fancy title with white text
            
            personalInfoPanel.add(createLabel("Name: " + rs.getString("FirstName") + " " + rs.getString("LastName")));
            personalInfoPanel.add(createLabel("Gender: " + rs.getString("Gender")));
            personalInfoPanel.add(createLabel("Age: " + (2024 - rs.getDate("DateOfBirth").toLocalDate().getYear())));
            personalInfoPanel.add(createLabel("Country: " + rs.getString("Country")));
            personalInfoPanel.add(createLabel("City: " + rs.getString("City")));
            personalInfoPanel.add(createLabel("Marital Status: " + rs.getString("MaritalStatus")));
            personalInfoPanel.add(createLabel("Religion: " + rs.getString("Religion")));
            personalInfoPanel.add(createLabel("Sect: " + rs.getString("Sect")));
            personalInfoPanel.add(createLabel("Mother Tongue: " + rs.getString("MotherTongue")));
            personalInfoPanel.add(createLabel("Caste: " + rs.getString("Caste")));
            personalInfoPanel.add(createLabel("Disability: " + rs.getString("Disability")));
            personalInfoPanel.add(createLabel("Height: " + rs.getString("Height")));
            personalInfoPanel.add(createLabel("Smoke: " + rs.getString("Smoke")));
            personalInfoPanel.add(createLabel("Complexion: " + rs.getString("Complexion")));
            personalInfoPanel.add(createLabel("Hair Color: " + rs.getString("HairColor")));
            personalInfoPanel.add(createLabel("Weight: " + rs.getString("Weight")));
            personalInfoPanel.add(createLabel("Build: " + rs.getString("Build")));
            personalInfoPanel.add(createLabel("Eye Color: " + rs.getString("EyeColor")));

            // Career Info Panel
            JPanel careerInfoPanel = new JPanel();
            careerInfoPanel.setLayout(new BoxLayout(careerInfoPanel, BoxLayout.Y_AXIS));
            careerInfoPanel.setBackground(new Color(128, 0, 0)); // Maroon background
            careerInfoPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2),
                "Career Info",
                TitledBorder.LEFT, TitledBorder.TOP,
                new Font("Serif", Font.BOLD, 16), Color.WHITE));  // Fancy title with white text
            
            careerInfoPanel.add(createLabel("Qualification: " + rs.getString("QualificationType")));
            careerInfoPanel.add(createLabel("Profession: " + rs.getString("QualificationProfession")));
            careerInfoPanel.add(createLabel("Monthly Income: " + rs.getString("MonthlyIncome")));
            careerInfoPanel.add(createLabel("Job Post: " + rs.getString("JobName")));
            careerInfoPanel.add(createLabel("University: " + rs.getString("University")));
            careerInfoPanel.add(createLabel("Major course: " + rs.getString("MajorCourse")));
            careerInfoPanel.add(createLabel("Future Plan: " + rs.getString("FuturePlan")));

            // Expectations Panel
            JPanel expectationsPanel = new JPanel();
            expectationsPanel.setLayout(new BoxLayout(expectationsPanel, BoxLayout.Y_AXIS));
            expectationsPanel.setBackground(new Color(128, 0, 0)); // Maroon background
            expectationsPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2),
                "Expectations",
                TitledBorder.LEFT, TitledBorder.TOP,
                new Font("Serif", Font.BOLD, 16), Color.WHITE));  // Fancy title with white text
           
            expectationsPanel.add(createLabel("Expected Gender: " + rs.getString("ExpectationGender")));
            expectationsPanel.add(createLabel("Expected Age: " + rs.getString("ExpectationAgeFrom") + " - " + rs.getString("ExpectationAgeTo")));
            expectationsPanel.add(createLabel("Expected Country: " + rs.getString("ExpectationCountry")));
            expectationsPanel.add(createLabel("Expected Profession: " + rs.getString("ExpectationProfession")));
            expectationsPanel.add(createLabel("Expected Marital Status: " + rs.getString("ExpectationMaritalStatus")));
            expectationsPanel.add(createLabel("Expected Height: " + rs.getString("ExpectationHeight")));
            expectationsPanel.add(createLabel("Expected Caste: " + rs.getString("ExpectationCaste")));
            expectationsPanel.add(createLabel("Expected Disability: " + rs.getString("ExpectationDisability")));
            expectationsPanel.add(createLabel("Expected Build: " + rs.getString("ExpectationBuild")));
            expectationsPanel.add(createLabel("Expected Religion: " + rs.getString("ExpectationReligion")));
            expectationsPanel.add(createLabel("Expected Monthly Income: " + rs.getString("ExpectationMonthlyIncome")));

            // Create a scrollable container for all the panels
            JPanel rightPanel = new JPanel();
            rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS)); // Stack vertically
            rightPanel.add(personalInfoPanel);
            rightPanel.add(careerInfoPanel);
            rightPanel.add(expectationsPanel);

            // Wrap everything inside a JScrollPane
            JScrollPane scrollPane = new JScrollPane(rightPanel);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

            profileFrame.add(profileDetailsPanel, BorderLayout.WEST);
            profileFrame.add(scrollPane, BorderLayout.CENTER);

            SwingUtilities.invokeLater(() -> profileFrame.setVisible(true));
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error retrieving profile details: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

// Helper method to create labels with white font color
private JLabel createLabel(String text) {
    JLabel label = new JLabel(text);
    label.setForeground(Color.WHITE);  // Set the label text to white
    return label;
}
private String buildQuery() {
    StringBuilder query = new StringBuilder("SELECT * FROM UserProfileView WHERE 1=1 ");

    // Gender filter
    if (maleCheckBox.isSelected() || femaleCheckBox.isSelected()) {
        query.append("AND Gender IN (");
        if (maleCheckBox.isSelected()) query.append("?"); // Add male filter
        if (maleCheckBox.isSelected() && femaleCheckBox.isSelected()) query.append(", ");
        if (femaleCheckBox.isSelected()) query.append("?"); // Add female filter
        query.append(") ");
    }

    
    // Age range
    query.append("AND DATEDIFF(YEAR, DateOfBirth, GETDATE()) BETWEEN ? AND ? ");

    // Country filter (changed to text field)
    String country = countryTextField.getText().trim(); // Get country from text field
    if (!country.isEmpty()) {
        query.append("AND Country = ? ");
    }

    return query.toString();
}


    private void createCareerInfoPanel() {
        if (careerPanel == null) {
            careerPanel = new JPanel();
            careerPanel.setLayout(new GridLayout(0, 2, 10, 10));
            careerPanel.setBorder(BorderFactory.createTitledBorder("Career Info"));

            // Qualification Dropdown
            careerPanel.add(new JLabel("Qualification:"));
            String[] qualifications = {"Bachelor's", "Master's", "PhD", "Other"};
            qualificationDropdown = new JComboBox<>(qualifications);
            careerPanel.add(qualificationDropdown);

            // Profession Dropdown
            careerPanel.add(new JLabel("Profession:"));
            String[] professions = {"Engineer", "Doctor", "Teacher", "Business", "Other"};
            professionDropdown = new JComboBox<>(professions);
            careerPanel.add(professionDropdown);

            // Income Dropdown
            careerPanel.add(new JLabel("Monthly Income:"));
            String[] incomes = {"< 5000", "5000 - 10000", "10000 - 20000", "> 20000"};
            incomeDropdown = new JComboBox<>(incomes);
            careerPanel.add(incomeDropdown);

            mainPanel.add(careerPanel, BorderLayout.CENTER);
        }
        careerPanel.setVisible(true);
    }
        public static void main(String[] args) {
   
}

    }
