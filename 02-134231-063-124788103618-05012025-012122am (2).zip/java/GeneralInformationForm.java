import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class GeneralInformationForm extends JFrame {

    private JTextField firstNameField, lastNameField, usernameField, emailField, phoneField, dobField, countryField, cityField;
    private JPasswordField passwordField;
    private JComboBox<String> genderField, motherTongueField, maritalStatusField, casteField;
    private int userID;

    public GeneralInformationForm() {

        setTitle("General Information");
        setLayout(new GridLayout(15, 2));

        // Set background color to dark maroon
        getContentPane().setBackground(new Color(128, 0, 0));

        // Create and customize labels with white font color
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setForeground(Color.WHITE);
        add(firstNameLabel);
        firstNameField = new JTextField();
        add(firstNameField);

        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setForeground(Color.WHITE);
        add(lastNameLabel);
        lastNameField = new JTextField();
        add(lastNameField);

        JLabel usernameLabel = new JLabel("Username:");
        usernameLabel.setForeground(Color.WHITE);
        add(usernameLabel);
        usernameField = new JTextField();
        add(usernameField);

        JLabel passwordLabel = new JLabel("Password (max 20 chars):");
        passwordLabel.setForeground(Color.WHITE);
        add(passwordLabel);
        passwordField = new JPasswordField();
        passwordField.setDocument(new JTextFieldLimit(20)); // Limit input to 20 characters
        add(passwordField);

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setForeground(Color.WHITE);
        add(emailLabel);
        emailField = new JTextField();
        add(emailField);

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setForeground(Color.WHITE);
        add(phoneLabel);
        phoneField = new JTextField();
        add(phoneField);

        JLabel genderLabel = new JLabel("Gender:");
        genderLabel.setForeground(Color.WHITE);
        add(genderLabel);
        genderField = new JComboBox<>(new String[]{"Male", "Female"});
        add(genderField);

        JLabel dobLabel = new JLabel("Date of Birth (YYYY-MM-DD):");
        dobLabel.setForeground(Color.WHITE);
        add(dobLabel);
        dobField = new JTextField();
        add(dobField);

        JLabel countryLabel = new JLabel("Country:");
        countryLabel.setForeground(Color.WHITE);
        add(countryLabel);
        countryField = new JTextField();
        add(countryField);

        JLabel cityLabel = new JLabel("City:");
        cityLabel.setForeground(Color.WHITE);
        add(cityLabel);
        cityField = new JTextField();
        add(cityField);

        JLabel motherTongueLabel = new JLabel("Mother Tongue:");
        motherTongueLabel.setForeground(Color.WHITE);
        add(motherTongueLabel);
        motherTongueField = new JComboBox<>(new String[]{"Urdu", "Punjabi", "Sindhi", "Pashto", "Others"});
        add(motherTongueField);

        JLabel maritalStatusLabel = new JLabel("Marital Status:");
        maritalStatusLabel.setForeground(Color.WHITE);
        add(maritalStatusLabel);
        maritalStatusField = new JComboBox<>(new String[]{"Single", "Married", "Divorced", "Widowed"});
        add(maritalStatusField);

        JLabel casteLabel = new JLabel("Caste:");
        casteLabel.setForeground(Color.WHITE);
        add(casteLabel);
        casteField = new JComboBox<>(new String[]{"Syed", "Sheikh", "Rajput", "Jutt","Siddiqui", "Sheikh", "Other"});
        add(casteField);

        // Submit button with white text
        JButton submitButton = new JButton("Submit");
        submitButton.setBackground(new Color(128, 0, 0)); // Dark maroon background for the button
        submitButton.setForeground(Color.WHITE); // White text for the button
        submitButton.addActionListener(e -> insertUser());
        add(submitButton);

        setSize(400, 700);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    private boolean isUnique(String column, String value) {
        try (Connection con = DatabaseConnection.connect();
             PreparedStatement ps = con.prepareStatement("SELECT COUNT(*) FROM [User] WHERE " + column + " = ?")) {
            ps.setString(1, value);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt(1) == 0;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void insertUser() {
        String firstName = firstNameField.getText();
        String lastName = lastNameField.getText();
        String username = usernameField.getText();
        String password = new String(passwordField.getPassword());
        String email = emailField.getText();
        String phone = phoneField.getText();
        String gender = (String) genderField.getSelectedItem();
        String dob = dobField.getText();
        String country = countryField.getText();
        String city = cityField.getText();
        String motherTongue = (String) motherTongueField.getSelectedItem();
        String maritalStatus = (String) maritalStatusField.getSelectedItem();
        String caste = (String) casteField.getSelectedItem();

        // Validate fields
        if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty()
                || email.isEmpty() || phone.isEmpty() || gender.isEmpty() || dob.isEmpty()
                || country.isEmpty() || city.isEmpty() || motherTongue.isEmpty()
                || maritalStatus.isEmpty() || caste.isEmpty()) {
            JOptionPane.showMessageDialog(this, "All fields are required!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!isUnique("UserName", username)) {
            JOptionPane.showMessageDialog(this, "Username already exists!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        if (!isUnique("Email", email)) {
            JOptionPane.showMessageDialog(this, "Email already exists!", "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        String query = "INSERT INTO [User] (City, Email, MotherTongue, MaritalStatus, Caste, DateOfBirth, UserName, DateJoined, Country, " +
                "FirstName, LastName, Phone, Gender, UserType, Pass) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, GETDATE(), ?, ?, ?, ?, ?, 'Candidate', ?)";

        try (Connection con = DatabaseConnection.connect();
             PreparedStatement ps = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, city);
            ps.setString(2, email);
            ps.setString(3, motherTongue);
            ps.setString(4, maritalStatus);
            ps.setString(5, caste);
            ps.setString(6, dob);
            ps.setString(7, username);
            ps.setString(8, country);
            ps.setString(9, firstName);
            ps.setString(10, lastName);
            ps.setString(11, phone);
            ps.setString(12, gender);
            ps.setString(13, password);

            // Execute the update
            ps.executeUpdate();

            // Get the generated keys after execution
            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    userID = generatedKeys.getInt(1);
                }
            }

            JOptionPane.showMessageDialog(this, "User Registered Successfully!");
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }

        // Proceed to next form or close this form
        new PersonalInfoForm(userID).setVisible(true);
        this.dispose();
    }

    public static void main(String[] args) {
        new GeneralInformationForm();
    }
    static class JTextFieldLimit extends javax.swing.text.PlainDocument {
        private int limit;

        JTextFieldLimit(int limit) {
            this.limit = limit;
        }

        @Override
        public void insertString(int offset, String str, javax.swing.text.AttributeSet attr) throws javax.swing.text.BadLocationException {
            if (str == null || getLength() + str.length() > limit) {
                return;
            }
            super.insertString(offset, str, attr);
        }
    }
}
