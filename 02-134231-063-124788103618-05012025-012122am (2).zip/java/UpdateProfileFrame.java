
import java.awt.*;
import java.awt.Color;
import java.awt.event.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.text.SimpleDateFormat;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;

public class UpdateProfileFrame extends JFrame {

    private int userID;

    public UpdateProfileFrame(int userID) {
        this.userID = userID;
        setTitle("Update Profile");
        setSize(1200, 800);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Navbar
        JPanel navbar = new JPanel(new BorderLayout());
        navbar.setBackground(new Color(128, 0, 0)); // Maroon color
        navbar.setPreferredSize(new Dimension(1200, 100)); // Increased the height of the navbar

        // Back icon
        JButton backButton = new JButton(new ImageIcon("src/backIcon.png"));
        backButton.setBorderPainted(false);
        backButton.setContentAreaFilled(false);
        backButton.setFocusPainted(false);
        backButton.setCursor(new Cursor(Cursor.HAND_CURSOR));
       backButton.addActionListener(e -> {
    new AdminHome(userID); // Pass userID to AdminHome
    this.dispose();
});

        // Label in the center
        JLabel titleLabel = new JLabel("Update Data", JLabel.CENTER);
        titleLabel.setForeground(Color.WHITE); // Ensure you are using java.awt.Color
        titleLabel.setFont(new Font("Serif", Font.ITALIC, 50)); // Serif font, bold, size 50
        
        navbar.add(backButton, BorderLayout.WEST);
        navbar.add(titleLabel, BorderLayout.CENTER);

        // Content Panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new GridBagLayout()); // Use GridBagLayout for better control
        contentPanel.setBorder(new EmptyBorder(10, 20, 20, 20)); // Reduced extra spacing

        // GridBagConstraints for alignment and size
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.anchor = GridBagConstraints.CENTER;

        // Input fields
        JTextField firstNameField = new JTextField();
        JTextField lastNameField = new JTextField();
        JTextField emailField = new JTextField();
        JTextField phoneField = new JTextField();
        JTextField cityField = new JTextField();
        JTextField countryField = new JTextField();

        // Set the preferred size of the fields
        Dimension fieldSize = new Dimension(250, 30);
        firstNameField.setPreferredSize(fieldSize);
        lastNameField.setPreferredSize(fieldSize);
        emailField.setPreferredSize(fieldSize);
        phoneField.setPreferredSize(fieldSize);
        cityField.setPreferredSize(fieldSize);
        countryField.setPreferredSize(fieldSize);

        // Add focus listeners to change border color
        addFocusListener(firstNameField);
        addFocusListener(lastNameField);
        addFocusListener(emailField);
        addFocusListener(phoneField);
        addFocusListener(cityField);
        addFocusListener(countryField);

        // Labels and fields
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setForeground(new Color(128, 0, 0)); // Maroon color

        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setForeground(new Color(128, 0, 0));

        JLabel emailLabel = new JLabel("Email:");
        emailLabel.setForeground(new Color(128, 0, 0));

        JLabel phoneLabel = new JLabel("Phone:");
        phoneLabel.setForeground(new Color(128, 0, 0));

        JLabel cityLabel = new JLabel("City:");
        cityLabel.setForeground(new Color(128, 0, 0));

        JLabel countryLabel = new JLabel("Country:");
        countryLabel.setForeground(new Color(128, 0, 0));

        // Adding labels and fields to the content panel
        gbc.gridx = 0;
        gbc.gridy = 0;
        contentPanel.add(firstNameLabel, gbc);
        gbc.gridx = 1;
        contentPanel.add(firstNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 1;
        contentPanel.add(lastNameLabel, gbc);
        gbc.gridx = 1;
        contentPanel.add(lastNameField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 2;
        contentPanel.add(emailLabel, gbc);
        gbc.gridx = 1;
        contentPanel.add(emailField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 3;
        contentPanel.add(phoneLabel, gbc);
        gbc.gridx = 1;
        contentPanel.add(phoneField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 4;
        contentPanel.add(cityLabel, gbc);
        gbc.gridx = 1;
        contentPanel.add(cityField, gbc);

        gbc.gridx = 0;
        gbc.gridy = 5;
        contentPanel.add(countryLabel, gbc);
        gbc.gridx = 1;
        contentPanel.add(countryField, gbc);

        // Save Button (Placed below the data entry fields)
JButton saveButton = new JButton("Save Changes");
saveButton.setBackground(new Color(128, 0, 0)); // Maroon color
saveButton.setForeground(Color.white);
saveButton.setFont(new Font("Arial", Font.BOLD, 12)); // Decreased font size
saveButton.setPreferredSize(new Dimension(150, 30)); // Normal button size

// Mouse Listener for hover effect (glowing border)
saveButton.addMouseListener(new MouseAdapter() {
    @Override
    public void mouseEntered(MouseEvent e) {
        saveButton.setBorder(new LineBorder(new Color(128, 0, 0), 3)); // Glowing effect with thicker maroon border
        saveButton.setFont(new Font("Arial", Font.BOLD, 14)); // Slightly increase font size on hover
    }

    @Override
    public void mouseExited(MouseEvent e) {
        saveButton.setBorder(BorderFactory.createLineBorder(new Color(128, 0, 0), 1)); // Default maroon border
        saveButton.setFont(new Font("Arial", Font.BOLD, 12)); // Reset font size
    }
});

// Save action listener
saveButton.addActionListener(e -> saveProfileChanges(firstNameField, lastNameField, emailField, phoneField, cityField, countryField));

// Placing the Save button below the input fields in GridBagLayout
gbc.gridx = 1;
gbc.gridy = 7;
gbc.gridwidth = 2; // Make the button span both columns
contentPanel.add(saveButton, gbc);


        // Add Components
        add(navbar, BorderLayout.NORTH);
        add(contentPanel, BorderLayout.CENTER);
        setVisible(true);
    }

    // Focus listener to change field borders to maroon and bold on focus
    private void addFocusListener(JTextField textField) {
        textField.addFocusListener(new FocusAdapter() {
            @Override
            public void focusGained(FocusEvent e) {
                textField.setBorder(new LineBorder(new Color(128, 0, 0), 2)); // Maroon border
                textField.setFont(new Font("Arial", Font.BOLD, 12)); // Bold font
            }

            @Override
            public void focusLost(FocusEvent e) {
                textField.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1)); // Default border
                textField.setFont(new Font("Arial", Font.PLAIN, 12)); // Normal font
            }
        });
    }

    private void saveProfileChanges(JTextField firstNameField, JTextField lastNameField, JTextField emailField, JTextField phoneField, JTextField cityField, JTextField countryField) {
        try (Connection connection = DatabaseConnection.connect()) {
            if (connection != null) {
                // Update User table
                String updateUserQuery = "UPDATE [User] SET FirstName = ?, LastName = ?, Email = ?, Phone = ?, City = ?, Country = ? WHERE UserID = ?";
                PreparedStatement userStmt = connection.prepareStatement(updateUserQuery);
                userStmt.setString(1, firstNameField.getText());
                userStmt.setString(2, lastNameField.getText());
                userStmt.setString(3, emailField.getText());
                userStmt.setString(4, phoneField.getText());
                userStmt.setString(5, cityField.getText());
                userStmt.setString(6, countryField.getText());
                userStmt.setInt(7, userID);
                userStmt.executeUpdate();

              

                JOptionPane.showMessageDialog(this, "Profile updated successfully!");
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error updating profile. Please try again.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    }



    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 400, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 300, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

}  
   

    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables

