import javax.swing.*;
import java.awt.*;
import java.sql.*;

public class ReligionInfoForm extends JFrame {
    private JComboBox<String> religionField, hijabPreferenceField, convertedReligionField, performSalaahField, sectField, beardPreferenceField, keepHalalField;
    private int userID;
    private int AppearanceID;
    private int UserReligionID;

    public ReligionInfoForm(int userID, int AppearanceID) {
        this.userID = userID;
        this.AppearanceID = AppearanceID;

        setTitle("Religion Information");
        setLayout(new GridLayout(8, 2));
        getContentPane().setBackground(new Color(128, 0, 0)); // Set background color to dark maroon

        // Religion Dropdown
        add(createLabel("Religion:"));
        religionField = new JComboBox<>();
        populateReligionDropdown();
        add(religionField);

        // Hijab Preference
        add(createLabel("Hijab Preference:"));
        hijabPreferenceField = new JComboBox<>(new String[]{"Yes", "No"});
        add(hijabPreferenceField);

        // Converted Religion
        add(createLabel("Converted Religion:"));
        convertedReligionField = new JComboBox<>(new String[]{"Yes", "No"});
        add(convertedReligionField);

        // Perform Salaah
        add(createLabel("Perform Salaah:"));
        performSalaahField = new JComboBox<>(new String[]{"Yes", "No", "Sometimes"});
        add(performSalaahField);

        // Sect
        add(createLabel("Sect:"));
        sectField = new JComboBox<>(new String[]{"Shia", "Sunni","Protestant","Catholic","Other"});
        add(sectField);

        // Beard Preference
        add(createLabel("Beard Preference:"));
        beardPreferenceField = new JComboBox<>(new String[]{"Yes", "No"});
        add(beardPreferenceField);

        // Keep Halal
        add(createLabel("Keep Halal:"));
        keepHalalField = new JComboBox<>(new String[]{"Yes", "No", "Always"});
        add(keepHalalField);

        // Next Button
        JButton nextButton = new JButton("Next");
        nextButton.addActionListener(e -> insertAndFinish());
        add(nextButton);

        setSize(400, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setVisible(true);
    }

    // Helper method to create JLabels with white font
    private JLabel createLabel(String text) {
        JLabel label = new JLabel(text);
        label.setForeground(Color.WHITE); // Set font color to white
        return label;
    }

    // Method to populate the Religion dropdown from the Religion table
    void populateReligionDropdown() {
        try (Connection con = DatabaseConnection.connect();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT ReligionType FROM Religion")) {
            while (rs.next()) {
                religionField.addItem(rs.getString("ReligionType"));
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching religions: " + e.getMessage());
        }
    }

    private void insertAndFinish() {
        String religion = (String) religionField.getSelectedItem();
        String hijabPreference = (String) hijabPreferenceField.getSelectedItem();
        String convertedReligion = (String) convertedReligionField.getSelectedItem();
        String performSalaah = (String) performSalaahField.getSelectedItem();
        String sect = (String) sectField.getSelectedItem();
        String beardPreference = (String) beardPreferenceField.getSelectedItem();
        String keepHalal = (String) keepHalalField.getSelectedItem();

        int religionID = fetchReligionID(religion);
        if (religionID == -1) {
            JOptionPane.showMessageDialog(this, "Invalid Religion selected.");
            return;
        }

        String query = "INSERT INTO UserReligion (ReligionID, HijabPreference, ConvertedReligion, PerformSalah, Sect, BeardPreference, KeepHalal) " +
                       "VALUES (?, ?, ?, ?, ?, ?, ?)";

        try (Connection con = DatabaseConnection.connect();
             PreparedStatement ps = con.prepareStatement(query, Statement.RETURN_GENERATED_KEYS)) {

            ps.setInt(1, religionID);
            ps.setString(2, hijabPreference);
            ps.setString(3, convertedReligion);
            ps.setString(4, performSalaah);
            ps.setString(5, sect);
            ps.setString(6, beardPreference);
            ps.setString(7, keepHalal);

            ps.executeUpdate();

            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    UserReligionID = generatedKeys.getInt(1); // Get the generated UserReligionID
                }
            }

            JOptionPane.showMessageDialog(this, "Religion details saved successfully!");

        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error: " + e.getMessage());
        }

        // Proceed to the next form
        new CareerInfoForm(userID, AppearanceID, UserReligionID).setVisible(true);
        this.dispose(); // Close the current form
    }

    // Helper method to fetch the ReligionID from the Religion table based on ReligionType
    private int fetchReligionID(String religionName) {
        try (Connection con = DatabaseConnection.connect();
             PreparedStatement ps = con.prepareStatement("SELECT ReligionID FROM Religion WHERE ReligionType = ?")) {
            ps.setString(1, religionName);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return rs.getInt("ReligionID");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return -1; // Return -1 if no matching religion is found
    }
}
