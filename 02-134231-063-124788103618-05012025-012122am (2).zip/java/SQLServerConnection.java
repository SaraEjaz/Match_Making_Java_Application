import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class SQLServerConnection {
    public static void main(String[] args) {
        // Database credentials
        String url = "jdbc:sqlserver://localhost:1433;databaseName=PROJECT;encrypt=true;trustServerCertificate=true;";
        String user = "admin";
        String password = "12345";

        try {
            // Connect to SQL Server
            Connection connection = DriverManager.getConnection(url, user, password);
            System.out.println("Connected to the database successfully!");
            // Close the connection
            connection.close();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
}
