import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;

public class AboutUsPage extends JFrame {
     String username;
    int candidateId;
    public AboutUsPage(String username,int candidateId) {
        setTitle("About us Page");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setBackground(Color.red);
        setLayout(new BorderLayout());
this.username = username;
        this.candidateId = candidateId;

        // Header Panel with Text
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BorderLayout());

        // Add fancy text (shaadi.org.pk)
        JPanel textPanel = new JPanel();
        textPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 0)); // Centered with spacing

        JLabel shaadiLabel = new JLabel("shaadi.");
        shaadiLabel.setFont(new Font("Arial", Font.BOLD, 50));
        shaadiLabel.setForeground(Color.WHITE);

        JLabel orgLabel = new JLabel("org.");
        orgLabel.setFont(new Font("Arial", Font.ITALIC, 50));
        orgLabel.setForeground(Color.WHITE);

        JLabel pkLabel = new JLabel("pk");
        pkLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 50));
        pkLabel.setForeground(Color.WHITE);

        // Add labels to textPanel
        textPanel.add(shaadiLabel);
        textPanel.add(orgLabel);
        textPanel.add(pkLabel);
        textPanel.setBackground(new Color(128, 0, 0));
        textPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Add textPanel to headerPanel
        headerPanel.add(textPanel, BorderLayout.CENTER);
        headerPanel.setBackground(new Color(128, 0, 0));
        headerPanel.setPreferredSize(new Dimension(getWidth(), 100)); // Adjust size as needed
        add(headerPanel, BorderLayout.NORTH);

        // Content Panel with Images
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS)); // Arrange components vertically

        // Add the first image
        JPanel imagePanel1 = new JPanel();
        imagePanel1.setBackground(new Color(128, 0, 0)); // Maroon background
        imagePanel1.setLayout(new BorderLayout()); // Use BorderLayout for proper alignment

        try {
            // Load image from file (aus1.jpeg)
            BufferedImage img1 = ImageIO.read(new File("images/aus4.jpeg"));
            if (img1 == null) {
                System.out.println("First image loading failed.");
            } else {
                System.out.println("First image loaded successfully. Width: " + img1.getWidth() + ", Height: " + img1.getHeight());
                ImageIcon imgIcon1 = new ImageIcon(img1.getScaledInstance(850, 350, Image.SCALE_SMOOTH));
                JLabel imgLabel1 = new JLabel(imgIcon1);
                imagePanel1.add(imgLabel1, BorderLayout.CENTER);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        contentPanel.add(imagePanel1);

        // Add the second image
        JPanel imagePanel3 = new JPanel();
        imagePanel3.setBackground(new Color(128, 0, 0)); // Maroon background
        imagePanel3.setLayout(new BorderLayout()); // Use BorderLayout for proper alignment
        try {
            // Load image from file (aus2.jpeg)
            BufferedImage img3 = ImageIO.read(new File("images/pmc.jpeg"));
            if (img3 == null) {
                System.out.println("Second image loading failed.");
            } else {
                System.out.println("Second image loaded successfully. Width: " + img3.getWidth() + ", Height: " + img3.getHeight());
                ImageIcon imgIcon3 = new ImageIcon(img3.getScaledInstance(850, 350, Image.SCALE_SMOOTH)); // Resize the image as needed
                JLabel imgLabel3 = new JLabel(imgIcon3);
                imagePanel3.add(imgLabel3, BorderLayout.CENTER);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        contentPanel.add(imagePanel3);

        // Add the third image
        JPanel imagePanel2 = new JPanel();
        imagePanel2.setBackground(new Color(128, 0, 0)); // Maroon background
        imagePanel2.setLayout(new BorderLayout()); // Use BorderLayout for proper alignment
        try {
            // Load image from file (aus2.jpeg)
            BufferedImage img2 = ImageIO.read(new File("images/imgg.jpeg"));
            if (img2 == null) {
                System.out.println("Second image loading failed.");
            } else {
                System.out.println("Second image loaded successfully. Width: " + img2.getWidth() + ", Height: " + img2.getHeight());
                ImageIcon imgIcon2 = new ImageIcon(img2.getScaledInstance(1350, 350, Image.SCALE_SMOOTH)); // Resize the image as needed
                JLabel imgLabel2 = new JLabel(imgIcon2);
                imagePanel2.add(imgLabel2, BorderLayout.CENTER);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        contentPanel.add(imagePanel2);

        // Scroll Pane for contentPanel
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); // Enable vertical scrolling
        add(scrollPane, BorderLayout.CENTER);

        // Back Button
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.PLAIN, 18));
        backButton.setForeground(Color.WHITE);
        backButton.setBackground(new Color(128, 0, 0)); // Maroon background for the button
        backButton.addActionListener(e -> {
            new WelcomePage(username, candidateId).setVisible(true); // Navigate to the WelcomePage
            dispose(); // Close the current AboutUsPage window
        });

        // Add Back Button at the bottom
        JPanel buttonPanel = new JPanel();
        buttonPanel.setBackground(new Color(128, 0, 0)); // Set background to maroon
        buttonPanel.add(backButton);
        add(buttonPanel, BorderLayout.SOUTH);

        // Set window properties
        setLocationRelativeTo(null); // Center the window
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {
                setVisible(true);
            }
        });
    }

    public static void main(String[] args) {
       
    }
}
