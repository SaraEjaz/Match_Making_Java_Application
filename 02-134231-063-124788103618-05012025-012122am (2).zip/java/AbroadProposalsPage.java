import javax.swing.*;
import java.awt.*;
import static java.awt.Color.BLACK;
import java.awt.event.*;
import java.sql.*;
import javax.swing.border.TitledBorder;

public class AbroadProposalsPage extends JFrame {
    private int candidateId;
    private JPanel resultsPanel;
    private String username;

    public AbroadProposalsPage(String username, int candidateId) {
        this.username = username;
        this.candidateId = candidateId;
        this.resultsPanel = new JPanel();
        this.resultsPanel.setLayout(new BoxLayout(resultsPanel, BoxLayout.Y_AXIS));

        setTitle("Abroad Proposals");
        setSize(600, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());
          // Add the header panel
        add(createHeaderPanel(), BorderLayout.NORTH);
        JScrollPane scrollPane = new JScrollPane(resultsPanel);
        add(scrollPane, BorderLayout.CENTER);
        setVisible(true);

        performSearch();
    }
  private JPanel createHeaderPanel() {
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BorderLayout());
        headerPanel.setBackground(new Color(128, 0, 0)); // Maroon background color
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Padding around the panel

        // Back button
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Serif", Font.BOLD, 14));
        backButton.setBackground(Color.WHITE);
        backButton.setForeground(new Color(128, 0, 0)); // Maroon text
        backButton.addActionListener(e -> goBackToWelcomePage());
        headerPanel.add(backButton, BorderLayout.WEST);

        // Fancy text
        JLabel titleLabel = new JLabel("Shaadi.org.pk", SwingConstants.CENTER);
        titleLabel.setFont(new Font("Serif", Font.BOLD, 24));
        titleLabel.setForeground(Color.WHITE);
        headerPanel.add(titleLabel, BorderLayout.CENTER);

        return headerPanel;
    }
    private void goBackToWelcomePage() {
        
        dispose(); // Close the current window
        // Open the WelcomePage (replace with actual welcome page logic)
        new WelcomePage(username,candidateId); // Replace with your WelcomePage class if available
    }
    // Get the candidate's country based on CandidateID
    private String getCandidateCountry(int candidateId) throws SQLException {
        String country = null;
        String query = "SELECT u.Country FROM [User] u " +
                       "JOIN Candidate c ON u.UserID = c.UserID " +
                       "WHERE c.CandidateID = ?";
        try (Connection connection = DatabaseConnection.connect();
             PreparedStatement statement = connection.prepareStatement(query)) {
            statement.setInt(1, candidateId);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                country = rs.getString("Country");
            }
        }
        return country;
    }

    // Build the query to search for profiles not from the same country as the candidate
    private String buildQuery() {
        return "SELECT * FROM UserProfileView WHERE Country != ?";
    }

    // Perform the search to fetch profiles from different countries
    private void performSearch() {
        resultsPanel.removeAll(); // Clear previous results
        resultsPanel.revalidate();
        resultsPanel.repaint();

        try {
            // Fetch candidate's country
            String candidateCountry = getCandidateCountry(candidateId);

            // Build the query to exclude profiles from the same country
            String query = buildQuery();

            System.out.println("Executing Query: " + query); // Log the query for debugging

            try (Connection connection = DatabaseConnection.connect();
                 PreparedStatement statement = connection.prepareStatement(query)) {

                // Set the candidate's country to exclude them
                statement.setString(1, candidateCountry);

                // Execute the query and process the results
                ResultSet rs = statement.executeQuery();
                boolean hasResults = false;
                JPanel rowPanel = new JPanel();
                rowPanel.setLayout(new GridLayout(0, 3)); // Grid layout to show 3 profiles per row

                while (rs.next()) {
                    hasResults = true;
                    int userId = rs.getInt("UserID");
                    String profilePicPrivacy = rs.getString("PrivacyStatus");
                    byte[] profileImageBytes = rs.getBytes("ProfileImage");

                    // Create the profile panel with a maroon background
                    JPanel profilePanel = new JPanel();
                    profilePanel.setLayout(new BoxLayout(profilePanel, BoxLayout.Y_AXIS));
                    profilePanel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));
                    profilePanel.setBackground(new Color(128, 0, 0));  // Maroon background color

                    // Create and display profile details
                    JLabel imageLabel;
                    if (profilePicPrivacy == null || !profilePicPrivacy.equalsIgnoreCase("Only Me")) {
                        if (profileImageBytes != null) {
                            ImageIcon profileImage = new ImageIcon(profileImageBytes);
                            Image img = profileImage.getImage();
                            Image scaledImg = img.getScaledInstance(150, 150, Image.SCALE_SMOOTH); // Scale to 150x150
                            imageLabel = new JLabel(new ImageIcon(scaledImg));
                        } else {
                            imageLabel = new JLabel("No Profile Picture");
                        }
                    } else {
                        imageLabel = new JLabel("Profile Picture Hidden");
                    }

                    imageLabel.setForeground(Color.WHITE); // Set text color of the label to white
                    profilePanel.add(imageLabel);

                    // Add profile information with white text
                    profilePanel.add(new JLabel("Profession: " + rs.getString("QualificationProfession")));
                    profilePanel.add(new JLabel("Monthly Income: " + rs.getInt("MonthlyIncome")));
                    profilePanel.add(new JLabel("Gender: " + rs.getString("Gender")));

                    // Set text color for labels inside the profile panel
                    for (Component comp : profilePanel.getComponents()) {
                        if (comp instanceof JLabel) {
                            ((JLabel) comp).setForeground(Color.WHITE);  // Set label text to white
                        }
                    }

                    // Add buttons for "View Profile" and "Chat"
                    JButton viewProfileButton = new JButton("View Profile");
                    viewProfileButton.addActionListener(e -> showProfileDetails(userId));
                    profilePanel.add(viewProfileButton);

                    JButton chatButton = new JButton("Chat");
                    // Pass userId (receiverId) to openChatWindow
                    chatButton.addActionListener(e -> openChatWindow(userId));
                    profilePanel.add(chatButton);

                    rowPanel.add(profilePanel);

                    // If 3 profiles are added, add the row to the main panel and reset
                    if (rowPanel.getComponentCount() == 3) {
                        resultsPanel.add(rowPanel);
                        rowPanel = new JPanel();
                        rowPanel.setLayout(new GridLayout(0, 3)); // Reset the row panel for the next set of profiles
                    }
                }

                // If there are remaining profiles in the row (less than 3)
                if (rowPanel.getComponentCount() > 0) {
                    resultsPanel.add(rowPanel);
                }

                if (!hasResults) {
                    resultsPanel.add(new JLabel("No matching profiles found."));
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error retrieving profiles: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

 private void showProfileDetails(int userId) {
    try (Connection connection = DatabaseConnection.connect()) {
        String query = "SELECT * FROM UserProfileView WHERE UserID = ?";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, userId);
        ResultSet rs = statement.executeQuery();

        if (rs.next()) {
            JFrame profileFrame = new JFrame("Profile Details");
            profileFrame.setSize(1000, 600);
            profileFrame.setLayout(new BorderLayout());
            profileFrame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

            // Set the background color of the entire JFrame to black
            profileFrame.getContentPane().setBackground(Color.BLACK);
profileFrame.setBackground(new Color(128,0,0));
            // Create a panel for profile image and other details
            JPanel profileDetailsPanel = new JPanel();
            profileDetailsPanel.setLayout(new BorderLayout());
            profileDetailsPanel.setBackground(Color.BLACK);  // Set background to black

            // Check PrivacyStatus before displaying the profile image
            String privacyStatus = rs.getString("PrivacyStatus");

            JLabel imageLabel;
            if (privacyStatus != null && !privacyStatus.equalsIgnoreCase("Only Me")) {
                byte[] imageBytes = rs.getBytes("ProfileImage");
                if (imageBytes != null) {
                    ImageIcon profileImage = new ImageIcon(imageBytes);
                    Image img = profileImage.getImage();  // Image from ImageIcon
                    Image scaledImg = img.getScaledInstance(200, 200, Image.SCALE_SMOOTH); // Scale image to fit
                    ImageIcon scaledIcon = new ImageIcon(scaledImg);

                    imageLabel = new JLabel(scaledIcon);
                    imageLabel.setBorder(BorderFactory.createLineBorder(Color.GRAY, 2));  // Border around the image
                } else {
                    imageLabel = new JLabel("No profile picture available.");
                    imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
                    imageLabel.setForeground(Color.WHITE);  // Set text color to white
                }
            } else {
                imageLabel = new JLabel("Profile picture hidden due to privacy settings.");
                imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
                imageLabel.setForeground(Color.WHITE);  // Set text color to white
            }

            profileDetailsPanel.add(imageLabel, BorderLayout.WEST);

            // Create the personal information panel with a distinct background color and black border
            JPanel personalInfoPanel = new JPanel();
            personalInfoPanel.setLayout(new BoxLayout(personalInfoPanel, BoxLayout.Y_AXIS));
            personalInfoPanel.setBackground(new Color(128, 0, 0)); // Maroon background
            personalInfoPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2),
                "Personal Info",
                TitledBorder.LEFT, TitledBorder.TOP,
                new Font("Serif", Font.BOLD, 16), Color.WHITE));  // Fancy title with white text

            // Add labels with white font color
            personalInfoPanel.add(createLabel("Name: " + rs.getString("FirstName") + " " + rs.getString("LastName")));
            personalInfoPanel.add(createLabel("Gender: " + rs.getString("Gender")));
            personalInfoPanel.add(createLabel("Age: " + (2024 - rs.getDate("DateOfBirth").toLocalDate().getYear())));
            personalInfoPanel.add(createLabel("Country: " + rs.getString("Country")));
            personalInfoPanel.add(createLabel("City: " + rs.getString("City")));
            personalInfoPanel.add(createLabel("Marital Status: " + rs.getString("MaritalStatus")));
            personalInfoPanel.add(createLabel("Religion: " + rs.getString("Religion")));
            personalInfoPanel.add(createLabel("Sect: " + rs.getString("Sect")));
            personalInfoPanel.add(createLabel("Mother Tongue: " + rs.getString("MotherTongue")));
            personalInfoPanel.add(createLabel("Caste: " + rs.getString("Caste")));
            personalInfoPanel.add(createLabel("Disability: " + rs.getString("Disability")));
            personalInfoPanel.add(createLabel("Height: " + rs.getString("Height")));
            personalInfoPanel.add(createLabel("Smoke: " + rs.getString("Smoke")));
            personalInfoPanel.add(createLabel("Complexion: " + rs.getString("Complexion")));
            personalInfoPanel.add(createLabel("Hair Color: " + rs.getString("HairColor")));
            personalInfoPanel.add(createLabel("Weight: " + rs.getString("Weight")));
            personalInfoPanel.add(createLabel("Build: " + rs.getString("Build")));
            personalInfoPanel.add(createLabel("Eye Color: " + rs.getString("EyeColor")));

            // Career Info Panel
            JPanel careerInfoPanel = new JPanel();
            careerInfoPanel.setLayout(new BoxLayout(careerInfoPanel, BoxLayout.Y_AXIS));
            careerInfoPanel.setBackground(new Color(128, 0, 0)); // Maroon background
            careerInfoPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2),
                "Career Info",
                TitledBorder.LEFT, TitledBorder.TOP,
                new Font("Serif", Font.BOLD, 16), Color.WHITE));  // Fancy title with white text

            careerInfoPanel.add(createLabel("Qualification: " + rs.getString("QualificationType")));
            careerInfoPanel.add(createLabel("Profession: " + rs.getString("QualificationProfession")));
            careerInfoPanel.add(createLabel("Monthly Income: " + rs.getString("MonthlyIncome")));
            careerInfoPanel.add(createLabel("Job Post: " + rs.getString("JobName")));
            careerInfoPanel.add(createLabel("University: " + rs.getString("University")));
            careerInfoPanel.add(createLabel("Major course: " + rs.getString("MajorCourse")));
            careerInfoPanel.add(createLabel("Future Plan: " + rs.getString("FuturePlan")));

            // Expectations Panel
            JPanel expectationsPanel = new JPanel();
            expectationsPanel.setLayout(new BoxLayout(expectationsPanel, BoxLayout.Y_AXIS));
            expectationsPanel.setBackground(new Color(128, 0, 0)); // Maroon background
            expectationsPanel.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(Color.WHITE, 2),
                "Expectations",
                TitledBorder.LEFT, TitledBorder.TOP,
                new Font("Serif", Font.BOLD, 16), Color.WHITE));  // Fancy title with white text

            expectationsPanel.add(createLabel("Expected Gender: " + rs.getString("ExpectationGender")));
            expectationsPanel.add(createLabel("Expected Age: " + rs.getString("ExpectationAgeFrom") + " - " + rs.getString("ExpectationAgeTo")));
            expectationsPanel.add(createLabel("Expected Country: " + rs.getString("ExpectationCountry")));
            expectationsPanel.add(createLabel("Expected Profession: " + rs.getString("ExpectationProfession")));
            expectationsPanel.add(createLabel("Expected Marital Status: " + rs.getString("ExpectationMaritalStatus")));
            expectationsPanel.add(createLabel("Expected Height: " + rs.getString("ExpectationHeight")));
            expectationsPanel.add(createLabel("Expected Caste: " + rs.getString("ExpectationCaste")));
            expectationsPanel.add(createLabel("Expected Disability: " + rs.getString("ExpectationDisability")));
            expectationsPanel.add(createLabel("Expected Build: " + rs.getString("ExpectationBuild")));
            expectationsPanel.add(createLabel("Expected Religion: " + rs.getString("ExpectationReligion")));
            expectationsPanel.add(createLabel("Expected Monthly Income: " + rs.getString("ExpectationMonthlyIncome")));

            // Create a scrollable container for all the panels
            JPanel rightPanel = new JPanel();
            rightPanel.setLayout(new BoxLayout(rightPanel, BoxLayout.Y_AXIS)); // Stack vertically
            rightPanel.add(personalInfoPanel);
            rightPanel.add(careerInfoPanel);
            rightPanel.add(expectationsPanel);

            // Wrap everything inside a JScrollPane
            JScrollPane scrollPane = new JScrollPane(rightPanel);
            scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

            profileFrame.add(profileDetailsPanel, BorderLayout.WEST);
            profileFrame.add(scrollPane, BorderLayout.CENTER);

            SwingUtilities.invokeLater(() -> profileFrame.setVisible(true));
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error retrieving profile details: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

// Helper method to create labels with white font color
private JLabel createLabel(String text) {
    JLabel label = new JLabel(text);
    label.setForeground(Color.WHITE);  // Set the label text to white
    return label;
}



   private void openChatWindow(int receiverId) {
    try (Connection connection = DatabaseConnection.connect()) {
        // Get the candidate's packageID and subscription end date
        String packageQuery = "SELECT packageid, enddate FROM userPackages WHERE candidateid = ?";
        PreparedStatement packageStatement = connection.prepareStatement(packageQuery);
        packageStatement.setInt(1, candidateId);  // This is the current user (the candidate)
        ResultSet packageResult = packageStatement.executeQuery();

        boolean hasValidPackage1 = false; // Flag to check if package ID 1 is valid
        boolean hasValidPackage2 = false; // Flag to check if package ID 2 is valid

        // Loop through all the packages of the candidate
        while (packageResult.next()) {
            int packageId = packageResult.getInt("packageid");
            Date endDate = packageResult.getDate("enddate");

            // Check if packageID 1 is valid (not expired)
            if (packageId == 1 && endDate != null && endDate.after(new java.util.Date())) {
                hasValidPackage1 = true; // Package 1 is valid
            }

            // Check if packageID 2 is valid (not expired)
            if (packageId == 2 && endDate != null && endDate.after(new java.util.Date())) {
                hasValidPackage2 = true; // Package 2 is valid
            }
        }

        // If no valid package (either 1 or 2) found
        if (!hasValidPackage1 && !hasValidPackage2) {
            JOptionPane.showMessageDialog(this, "Your subscription has expired or you don't have an active package. Please renew it to chat.", "Subscription Expired", JOptionPane.WARNING_MESSAGE);
            return;
        }

        // If packageId 2 is valid, chat with everyone (no verification check)
        if (hasValidPackage2) {
            // Open chat window for all users, no verification check required
            Chat chatWindow = new Chat(username, receiverId); // receiverId is the user you're chatting with
            chatWindow.setVisible(true);
        } else if (hasValidPackage1) {
            // If packageId 1 is valid, check if the receiver is verified
            String verificationQuery = "SELECT isVerified FROM [user] WHERE userID = ?";
            PreparedStatement verificationStatement = connection.prepareStatement(verificationQuery);
            verificationStatement.setInt(1, receiverId); // Receiver's userId (who you're chatting with)
            ResultSet verificationResult = verificationStatement.executeQuery();

            if (verificationResult.next()) {
                String isVerified = verificationResult.getString("isVerified");

                // If the receiver is verified, show message and don't allow chat
                if (isVerified.equalsIgnoreCase("Yes")) {
                    JOptionPane.showMessageDialog(this, "You can only chat with unverified users with your current package.", "Verification Required", JOptionPane.WARNING_MESSAGE);
                } else {
                    // If the receiver is not verified, allow chat
                    Chat chatWindow = new Chat(username, receiverId);
                    chatWindow.setVisible(true);
                }
            }
        }
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error retrieving subscription or verification details: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

   

    public static void main(String[] args) {
    }
}
