import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
public class ContactUsPage extends JFrame {
     int candidateId;
String username;
    public ContactUsPage(int candidateId,String username) {
         this.candidateId = candidateId;
this.username=username;
        setTitle("About Us Page");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setBackground(Color.red);
        setLayout(new BorderLayout());

        // Header Panel with Text
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BorderLayout());

        // Add back button to the header panel (aligned left)
        JButton backButton = new JButton("Back");
        backButton.setFont(new Font("Arial", Font.PLAIN, 16));
        backButton.setForeground(Color.WHITE);
        backButton.setBackground(Color.DARK_GRAY);
        backButton.addActionListener(e -> navigateToWelcomePage());
        
        JPanel backButtonPanel = new JPanel();
        backButtonPanel.setLayout(new FlowLayout(FlowLayout.LEFT));
        backButtonPanel.add(backButton);
        backButtonPanel.setBackground(new Color(128, 0, 0));
        
        headerPanel.add(backButtonPanel, BorderLayout.WEST);

        // Add fancy text (shaadi.org.pk)
        JPanel textPanel = new JPanel();
        textPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 0)); // Centered with spacing

        JLabel shaadiLabel = new JLabel("shaadi.");
        shaadiLabel.setFont(new Font("Arial", Font.BOLD, 50));
        shaadiLabel.setForeground(Color.WHITE);

        JLabel orgLabel = new JLabel("org.");
        orgLabel.setFont(new Font("Arial", Font.ITALIC, 50));
        orgLabel.setForeground(Color.WHITE);

        JLabel pkLabel = new JLabel("pk");
        pkLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 50));
        pkLabel.setForeground(Color.WHITE);

        // Add labels to textPanel
        textPanel.add(shaadiLabel);
        textPanel.add(orgLabel);
        textPanel.add(pkLabel);
        textPanel.setBackground(new Color(128, 0, 0));
        textPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        // Add textPanel to headerPanel
        headerPanel.add(textPanel, BorderLayout.CENTER);
        headerPanel.setBackground(new Color(128, 0, 0));
        headerPanel.setPreferredSize(new Dimension(getWidth(), 100)); // Adjust size as needed
        add(headerPanel, BorderLayout.NORTH);

        // Content Panel with Images
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS)); // Arrange components vertically

        // Add the first image
        JPanel imagePanel1 = new JPanel();
        imagePanel1.setBackground(new Color(128, 0, 0)); // Maroon background
        imagePanel1.setLayout(new BorderLayout()); // Use BorderLayout for proper alignment

        try {
            // Load image from file (contact.jpeg)
            BufferedImage img1 = ImageIO.read(new File("images/contact.jpeg"));
            if (img1 == null) {
                System.out.println("First image loading failed.");
            } else {
                System.out.println("First image loaded successfully. Width: " + img1.getWidth() + ", Height: " + img1.getHeight());
                ImageIcon imgIcon1 = new ImageIcon(img1.getScaledInstance(850, 250, Image.SCALE_SMOOTH));
                JLabel imgLabel1 = new JLabel(imgIcon1);
                imagePanel1.add(imgLabel1, BorderLayout.CENTER);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }

        contentPanel.add(imagePanel1);
        
        // Scroll Pane for contentPanel
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS); // Enable vertical scrolling
        add(scrollPane, BorderLayout.CENTER);

        // Set window properties
        setLocationRelativeTo(null); // Center the window
        SwingUtilities.invokeLater(() -> setVisible(true));
    }

    // Method to navigate to the WelcomePage
    private void navigateToWelcomePage() {
        // Dispose of the current frame
        dispose();

        // Open the WelcomePage (replace with your actual WelcomePage class)
        new WelcomePage(username,candidateId); // Replace with actual WelcomePage class
    }

     public static void main(String[] args) {
        
}
}