import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.util.ArrayList;

public class Chat extends JFrame {
    private String username;
    private int receiverId;
    private JPanel chatPanel;
    private JTextArea messageInput;
    private JButton sendButton;

    public Chat(String username, int receiverId) {
        this.username = username;
        this.receiverId = receiverId;

        setTitle("Chat Window");
        setSize(600, 400);
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // Chat display panel
        chatPanel = new JPanel();
        chatPanel.setLayout(new BoxLayout(chatPanel, BoxLayout.Y_AXIS));
        JScrollPane scrollPane = new JScrollPane(chatPanel);
        add(scrollPane, BorderLayout.CENTER);

        // Input panel for sending messages
        JPanel inputPanel = new JPanel(new BorderLayout());
        messageInput = new JTextArea(3, 20);
        sendButton = new JButton("Send");
        inputPanel.add(new JScrollPane(messageInput), BorderLayout.CENTER);
        inputPanel.add(sendButton, BorderLayout.EAST);
        add(inputPanel, BorderLayout.SOUTH);

        // Load previous messages
        loadChatHistory();

        // Send button action
        sendButton.addActionListener(e -> sendMessage());
    }

   private void loadChatHistory() {
    chatPanel.removeAll();
    try (Connection connection = DatabaseConnection.connect()) {
        int loggedInUserId = getUserId(username, connection);
        System.out.println("Logged in UserID: " + loggedInUserId); // Debug statement

        String query = "SELECT SenderID, MessageContent, TimeSent FROM Messages " +
                       "WHERE (SenderID = ? AND ReceiverID = ?) OR (SenderID = ? AND ReceiverID = ?) " +
                       "ORDER BY TimeSent ASC";
        PreparedStatement statement = connection.prepareStatement(query);
        statement.setInt(1, loggedInUserId);
        statement.setInt(2, receiverId);
        statement.setInt(3, receiverId);
        statement.setInt(4, loggedInUserId);

        ResultSet rs = statement.executeQuery();
        while (rs.next()) {
            String sender = rs.getInt("SenderID") == loggedInUserId ? "You" : "User " + receiverId;
            String message = rs.getString("MessageContent");
            Timestamp timeSent = rs.getTimestamp("TimeSent");
            String timeSentStr = timeSent != null ? timeSent.toString() : "Unknown time";
            JLabel messageLabel = new JLabel("[" + timeSentStr + "] " + sender + ": " + message);
            chatPanel.add(messageLabel);
        }
        chatPanel.revalidate();
        chatPanel.repaint();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error loading chat history: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        ex.printStackTrace(); // Debugging output
    }
}

    private void sendMessage() {
        String message = messageInput.getText().trim();
        if (message.isEmpty()) return;

        try (Connection connection = DatabaseConnection.connect()) {
            String query = "INSERT INTO Messages (SenderID, ReceiverID, MessageContent, TimeSent) VALUES (?, ?, ?, GETDATE())";
            PreparedStatement statement = connection.prepareStatement(query);
            int senderId = getUserId(username, connection);
            statement.setInt(1, senderId);
            statement.setInt(2, receiverId);
            statement.setString(3, message);
            statement.executeUpdate();

            // Add the message to the chat panel
            JLabel messageLabel = new JLabel("[Now] You: " + message);
            chatPanel.add(messageLabel);
            chatPanel.revalidate();
            chatPanel.repaint();
            messageInput.setText("");
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error sending message: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }

 private int getUserId(String username, Connection connection) throws SQLException {
    System.out.println("Looking up UserID for username: " + username); // Debug statement
    String query = "SELECT UserID FROM [User] WHERE Username = ?";
    PreparedStatement statement = connection.prepareStatement(query);
    statement.setString(1, username);
    ResultSet rs = statement.executeQuery();
    if (rs.next()) {
        return rs.getInt("UserID");
    } else {
        throw new SQLException("User not found for username: " + username);
    }
}

 public static void main(String[] args) {
        new Chat("Farheen101",1);
    }
}