import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.awt.Color;
import javax.swing.border.TitledBorder;
    public class SignInPage extends JFrame {
    
    private JTextField usernameOrEmailField;
    private JPasswordField passwordField;

    public SignInPage() {
        setTitle("Sign In");
        setLayout(new BorderLayout());
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        // Header
        JPanel headerPanel = new JPanel();
        headerPanel.setBackground(new Color(128, 0, 0)); // Maroon background
        JLabel headerLabel = new JLabel("Sign In to Your Account", JLabel.CENTER);
        headerLabel.setForeground(Color.WHITE); // White font
        headerLabel.setFont(new Font("Arial", Font.BOLD, 24));
        headerPanel.add(headerLabel);
        add(headerPanel, BorderLayout.NORTH);

        // Form
        JPanel formPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        formPanel.add(new JLabel("Email/Username:"));
        usernameOrEmailField = new JTextField();
        formPanel.add(usernameOrEmailField);

        formPanel.add(new JLabel("Password:"));
        passwordField = new JPasswordField();
        formPanel.add(passwordField);

        JButton signInButton = new JButton("Sign In");
        signInButton.addActionListener(e -> signIn());
        formPanel.add(signInButton);

        JButton forgotPasswordButton = new JButton("Forgot Your Password?");
        forgotPasswordButton.addActionListener(e -> forgotPassword());
        formPanel.add(forgotPasswordButton);

        add(formPanel, BorderLayout.CENTER);

        // Footer
        JPanel footerPanel = new JPanel();
        JButton registerButton = new JButton("Register");
        registerButton.addActionListener(e -> openRegistrationForm());
        footerPanel.add(registerButton);
        add(footerPanel, BorderLayout.SOUTH);

        setSize(400, 300);
        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void signIn() {
    String usernameOrEmail = usernameOrEmailField.getText();
    String password = new String(passwordField.getPassword());

    String query = "SELECT * FROM [User] WHERE (UserName = ? OR Email = ?) AND Pass = ?";
    try (Connection con = DatabaseConnection.connect();
         PreparedStatement ps = con.prepareStatement(query)) {
        ps.setString(1, usernameOrEmail);
        ps.setString(2, usernameOrEmail);
        ps.setString(3, password);

        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            String firstName = rs.getString("FirstName");
            String username = rs.getString("UserName"); // Get the signed-in user's username
            int userId = rs.getInt("UserID");
            String userType = rs.getString("UserType"); // Get the user type (admin or regular)

            // Check if the user is an admin
            if ("admin".equalsIgnoreCase(userType)) {
                // Open AdminHomePage and pass the userId
                new AdminHome(userId).setVisible(true);
                    this.dispose();  // Close SignInPage
            } else {
                // Fetch CandidateID based on the UserID
                int candidateId = getCandidateId(userId, con);

                if (candidateId == -1) {
                    JOptionPane.showMessageDialog(this, "Candidate profile not found.", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }

                // Fetch the user's image from the UserImage table
                byte[] imageBytes = getUserImage(userId, con);

                // Pass CandidateID and other information to the WelcomePage
                new WelcomePage( username, candidateId); // Updated WelcomePage constructor
                this.dispose(); // Close SignInPage
            }
        } else {
            JOptionPane.showMessageDialog(this, "Invalid username/email or password.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}

    private int getCandidateId(int userId, Connection con) {
    String candidateQuery = "SELECT CandidateID FROM Candidate WHERE UserID = ?";
    try (PreparedStatement ps = con.prepareStatement(candidateQuery)) {
        ps.setInt(1, userId);
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getInt("CandidateID"); // Return the CandidateID
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return -1; // Return -1 if no CandidateID is found
}
   private byte[] getUserImage(int userId, Connection con) {
    System.out.println("Fetching image for UserID: " + userId); // Debugging log

    String imageQuery = "SELECT Picture FROM UserImage WHERE UserID = ?";
    try (PreparedStatement ps = con.prepareStatement(imageQuery)) {
        ps.setInt(1, userId);
        System.out.println("Executing query: " + ps.toString()); // Debugging log
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            return rs.getBytes("Picture"); // Return the image bytes
        }
    } catch (SQLException e) {
        e.printStackTrace();
    }
    return null; // Return null if no image found
}


    private void forgotPassword() {
    // Create a new dialog for Forgot Password logic
    JDialog dialog = new JDialog(this, "Forgot Password", true);
    dialog.setLayout(new GridLayout(3, 2, 10, 10));
    dialog.setSize(300, 150);
    
    // Create and add components to the dialog
    JLabel usernameLabel = new JLabel("Username:");
    JTextField usernameField = new JTextField();
    JLabel emailLabel = new JLabel("Email:");
    JTextField emailField = new JTextField();
    JButton resetButton = new JButton("Reset Password");
    
    dialog.add(usernameLabel);
    dialog.add(usernameField);
    dialog.add(emailLabel);
    dialog.add(emailField);
    dialog.add(resetButton);
    
    resetButton.addActionListener(e -> {
        String username = usernameField.getText();
        String email = emailField.getText();
        
        if (username.isEmpty() || email.isEmpty()) {
            JOptionPane.showMessageDialog(dialog, "Please fill out both fields.", "Error", JOptionPane.ERROR_MESSAGE);
        } else {
            resetPassword(username, email, dialog);
        }
    });
    
    dialog.setLocationRelativeTo(this);
    dialog.setVisible(true);
}

private void resetPassword(String username, String email, JDialog dialog) {
    String checkUserQuery = "SELECT * FROM [User] WHERE UserName = ? AND Email = ?";
    
    try (Connection con = DatabaseConnection.connect();
         PreparedStatement ps = con.prepareStatement(checkUserQuery)) {
        ps.setString(1, username);
        ps.setString(2, email);
        
        ResultSet rs = ps.executeQuery();
        if (rs.next()) {
            // If user is found, allow them to reset password
            String newPassword = JOptionPane.showInputDialog(dialog, "Enter new password:");
            
            if (newPassword != null && !newPassword.trim().isEmpty()) {
                String updatePasswordQuery = "UPDATE [User] SET Pass = ? WHERE UserName = ? AND Email = ?";
                try (PreparedStatement updatePs = con.prepareStatement(updatePasswordQuery)) {
                    updatePs.setString(1, newPassword);
                    updatePs.setString(2, username);
                    updatePs.setString(3, email);
                    
                    int rowsUpdated = updatePs.executeUpdate();
                    if (rowsUpdated > 0) {
                        JOptionPane.showMessageDialog(dialog, "Password successfully updated.", "Success", JOptionPane.INFORMATION_MESSAGE);
                        dialog.dispose();
                    } else {
                        JOptionPane.showMessageDialog(dialog, "Error updating password.", "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } else {
                JOptionPane.showMessageDialog(dialog, "Password cannot be empty.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } else {
            JOptionPane.showMessageDialog(dialog, "Username and email do not match.", "Error", JOptionPane.ERROR_MESSAGE);
        }
    } catch (SQLException ex) {
        ex.printStackTrace();
        JOptionPane.showMessageDialog(dialog, "Database error: " + ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
}


    private void openRegistrationForm() {
        new GeneralInformationForm(); // Open the registration form
        this.dispose(); // Close SignInPage
    }

    public static void main(String[] args) {
        new SignInPage();
    }
}