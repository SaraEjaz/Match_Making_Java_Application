import javax.swing.*;
import java.awt.*;
import static java.awt.Color.red;
import java.awt.event.*;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.IOException;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;

public class WelcomePage extends JFrame {
    private JLabel nameLabel;
    private JLabel imageLabel;
    private String userName;
    private int candidateId;

    public WelcomePage(String username, int candidateId) {
        setTitle("Welcome Page");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(800, 600);
        setBackground(Color.red);
        setLayout(new BorderLayout());
        this.userName = username;
        this.candidateId = candidateId;

        // Header with user name and profile image
        JPanel headerPanel = new JPanel();
        headerPanel.setLayout(new BorderLayout());
        
        // Add fancy text (shaadi.org.pk)
        JPanel textPanel = new JPanel();
        textPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 20, 0)); // Centered with spacing

        // "Shaadi"
        JLabel shaadiLabel = new JLabel("shaadi.");
        shaadiLabel.setFont(new Font("Arial", Font.BOLD, 50));
        shaadiLabel.setForeground(Color.WHITE);  // White text color

        // "org"
        JLabel orgLabel = new JLabel("org.");
        orgLabel.setFont(new Font("Arial", Font.ITALIC, 50));
        orgLabel.setForeground(Color.WHITE);  // White text color

        // "pk"
        JLabel pkLabel = new JLabel("pk");
        pkLabel.setFont(new Font("Comic Sans MS", Font.PLAIN, 50));
        pkLabel.setForeground(Color.WHITE);  // White text color

        // Add labels to textPanel
        textPanel.add(shaadiLabel);
        textPanel.add(orgLabel);
        textPanel.add(pkLabel);
textPanel.setBackground(new Color(128, 0, 0));
textPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        // Add textPanel to headerPanel
        headerPanel.add(textPanel, BorderLayout.CENTER);
        // Set the maroon background for headerPanel (for the panel with the text)
    headerPanel.setBackground(new Color(128, 0, 0)); // Maroon background
    headerPanel.setPreferredSize(new Dimension(getWidth(), 100)); // Adjust size as needed
    add(headerPanel, BorderLayout.NORTH);

       
        
JButton menuButton = new JButton("⋮");
menuButton.setFont(new Font("Arial", Font.BOLD, 18));
menuButton.setForeground(Color.WHITE);
menuButton.setBackground(new Color(128, 0, 0));
menuButton.setBorderPainted(false);
JPopupMenu popupMenu = new JPopupMenu();

JMenuItem logoutItem = new JMenuItem("Logout");
logoutItem.addActionListener(e -> {
    // Assuming 'candidateId' is the ID of the logged-in user
    new SignInPage().setVisible(true); // Show profile frame
    dispose();
});


popupMenu.add(logoutItem);



menuButton.addActionListener(e -> popupMenu.show(menuButton, menuButton.getWidth() / 2, menuButton.getHeight()));

        headerPanel.setBackground(new Color(128, 0, 0)); // Maroon background
        headerPanel.setPreferredSize(new Dimension(getWidth(), 100)); // Adjust size as needed
        add(headerPanel, BorderLayout.NORTH);
headerPanel.add(menuButton, BorderLayout.WEST);

        // Create menu bar with maroon background
        JMenuBar menuBar = new JMenuBar();
        menuBar.setBackground(new Color(128, 0, 0)); // Maroon background
        menuBar.setForeground(Color.WHITE);

        // Create menu items
        String[] menuItems = {
            "About Us", "Best Proposals", "Abroad Proposals", "Packages", "Contact Us"
        };
        for (String item : menuItems) {
            JMenuItem menuItem = new JMenuItem(item);
            menuItem.setForeground(Color.WHITE);
            menuItem.setBackground(new Color(128, 0, 0));
            menuItem.setFont(new Font("Arial", Font.BOLD, 14));
            menuItem.addActionListener(new MenuActionListener());
            menuBar.add(menuItem);
        }

        // Create Search menu with drop-down options
        JMenu searchMenu = new JMenu("Search");
        searchMenu.setForeground(Color.WHITE);
        searchMenu.setBackground(new Color(128, 0, 0));
        searchMenu.setFont(new Font("Arial", Font.BOLD, 14));

        // Create drop-down items
        String[] searchOptions = {
            "Quick Search", "Search by Career Info", "Search by Religion Info",
            "Search by Personal Info", "Search by Username"
        };

        for (String option : searchOptions) {
            JMenuItem searchItem = new JMenuItem(option);
            searchItem.setForeground(Color.WHITE);
            searchItem.setBackground(new Color(128, 0, 0));
            searchItem.setFont(new Font("Arial", Font.BOLD, 14));
            searchItem.addActionListener(new SearchActionListener());
            searchMenu.add(searchItem);
        }

        // Add the Search menu to the menu bar
        menuBar.add(searchMenu);

        // Add the menu bar to the frame
        setJMenuBar(menuBar);

        // Create a scrollable content panel
        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS)); // Arrange components vertically

        // Add the first image
        JPanel imagePanel1 = new JPanel();
        imagePanel1.setBackground(new Color(128, 0, 0)); // Maroon background
        imagePanel1.setLayout(new BorderLayout()); // Use BorderLayout for proper alignment
        try {
            // Load image from file (img.jpeg)
            BufferedImage img1 = ImageIO.read(new File("images/img.jpeg"));
            ImageIcon imgIcon1 = new ImageIcon(img1.getScaledInstance(850, 350, Image.SCALE_SMOOTH)); // Resize the image as needed
            JLabel imgLabel1 = new JLabel(imgIcon1);
            // Add padding around the image by adding an empty space around it
            imagePanel1.add(imgLabel1, BorderLayout.CENTER);
        } catch (IOException e) {
            e.printStackTrace();
        }
        contentPanel.add(imagePanel1);

        // Add the second image
        JPanel imagePanel2 = new JPanel();
        imagePanel2.setBackground(new Color(128, 0, 0)); // Maroon background
        imagePanel2.setLayout(new BorderLayout()); // Use BorderLayout for proper alignment
        try {
            // Load image from file (img1.jpeg)
            BufferedImage img2 = ImageIO.read(new File("images/img1.jpeg"));
            ImageIcon imgIcon2 = new ImageIcon(img2.getScaledInstance(950, 550, Image.SCALE_SMOOTH)); // Resize the image as needed
            JLabel imgLabel2 = new JLabel(imgIcon2);
            // Add padding around the image by adding an empty space around it
            imagePanel2.add(imgLabel2, BorderLayout.CENTER);
        } catch (IOException e) {
            e.printStackTrace();
        }
        contentPanel.add(imagePanel2);

        // Add the third image (similar to previous ones)
        JPanel imagePanel3 = new JPanel();
        imagePanel3.setBackground(new Color(128, 0, 0)); // Maroon background
        imagePanel3.setLayout(new BorderLayout()); // Use BorderLayout for proper alignment
        try {
            // Load image from file (img2.jpeg)
            BufferedImage img3 = ImageIO.read(new File("images/img2.jpeg"));
            ImageIcon imgIcon3 = new ImageIcon(img3.getScaledInstance(950, 550, Image.SCALE_SMOOTH)); // Resize the image as needed
            JLabel imgLabel3 = new JLabel(imgIcon3);
            // Add padding around the image by adding an empty space around it
            imagePanel3.add(imgLabel3, BorderLayout.CENTER);
        } catch (IOException e) {
            e.printStackTrace();
        }
        contentPanel.add(imagePanel3);

        // Wrap the content in a JScrollPane
        JScrollPane scrollPane = new JScrollPane(contentPanel);
        add(scrollPane, BorderLayout.CENTER);

        setLocationRelativeTo(null); // Center the window
        setVisible(true); // Make the window visible
    }

    private class MenuActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
            switch (command) {
               
                case "About Us":
                    new AboutUsPage(userName, candidateId); // Navigate to AboutUsPage
                    break;
                case "Best Proposals":
                {
                    try {
                        new BestProposals(userName, candidateId); // Navigate to BestProposalsPage
                    } catch (SQLException ex) {
                        Logger.getLogger(WelcomePage.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
                    break;

                case "Abroad Proposals":
                    new AbroadProposalsPage(userName, candidateId); // Navigate to AbroadProposalsPage
                    break;
                case "Packages":
                    new PackageSelection(candidateId,userName); // Navigate to PackagesPage
                    break;
                case "Contact Us":
                    new ContactUsPage(candidateId,userName); // Navigate to ContactUsPage
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Unknown option selected.");
                    break;
            }
            dispose(); // Close WelcomePage
        }
    }

    private class SearchActionListener implements ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            String command = e.getActionCommand();
            switch (command) {
                case "Quick Search":
                    SearchPage searchPage = new SearchPage(userName, candidateId); // Create an instance of SearchPage
                    searchPage.setVisible(true); // Make it visible
                    break;
                case "Search by Career Info":
                    SearchByCareerInfo sbci = new SearchByCareerInfo(userName, candidateId); // Navigate to SearchByCareerInfo
                    sbci.setVisible(true);
                    break;
                case "Search by Religion Info":
                  SearchByReligionInfo rel=  new SearchByReligionInfo(userName, candidateId); // Navigate to SearchByReligionInfo
                  rel.setVisible(true);
                    break;
                case "Search by Personal Info":
                    SearchByPersonalInfo SBPI = new SearchByPersonalInfo(userName, candidateId); // Navigate to SearchByPersonalInfo
                    SBPI.setVisible(true);
                    break;
                case "Search by Username":
                   SearchByUsername SBuser= new SearchByUsername(userName, candidateId); // Navigate to SearchByUsername
                   SBuser.setVisible(true);
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Unknown search option selected.");
                    break;
            }
            dispose(); // Close WelcomePage
        }
    }
}
