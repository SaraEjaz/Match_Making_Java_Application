﻿CREATE TABLE [User] (
UserID INT IDENTITY(1,1) PRIMARY KEY, 
City VARCHAR(20) NOT NULL,
Email VARCHAR(50) unique,
MotherTongue VARCHAR(20) NOT NULL,
MaritalStatus VARCHAR(20) NOT NULL, 
Caste VARCHAR(20) NOT NULL,
DateOfBirth DATE NOT NULL,
UserName VARCHAR(50) Not NULL,
DateJoined DATE NOT NULL,
Country VARCHAR(20) NOT NULL,
FirstName VARCHAR(30) NOT NULL, 
LastName VARCHAR(30) NOT NULL,
Phone VARCHAR(11) NOT NULL,
Gender VARCHAR(10) NOT NULL,
isVerified VARCHAR(5) DEFAULT 'No',
UserType VARCHAR(10) NOT NULL, -- candidate,admin 
Pass VARCHAR(20) NOT NULL
);




CREATE TABLE Admin (
Admin_ID INT IDENTITY(1,1) PRIMARY KEY,
 
UserID INT NOT NULL,
FOREIGN KEY (UserID) REFERENCES [User](UserID)
);
CREATE TABLE Candidate (
CandidateID INT IDENTITY(1,1) PRIMARY KEY, UserID INT NOT NULL UNIQUE,
UserQualificationID INT UNIQUE NOT NULL, -- Links to UserQualification 
UserJobID INT UNIQUE NOT NULL,	-- Links to UserJob
ImageID INT UNIQUE NOT NULL,		-- Links to UserImage 
AppearanceID INT UNIQUE NOT NULL,			-- Links to Appearance
UserReligionID INT UNIQUE NOT NULL,			 -- Links to UserReligion
ExpID INT UNIQUE NOT NULL,	-- Links to Expectations
FOREIGN KEY (UserID) REFERENCES [User](UserID),
FOREIGN KEY (UserQualificationID) REFERENCES UserQualification(UserQualificationID),
FOREIGN KEY (UserJobID) REFERENCES UserJob(UserJobID), FOREIGN KEY (ImageID) REFERENCES UserImage(ImageID),
FOREIGN KEY (AppearanceID) REFERENCES Appearance(AppearanceID), FOREIGN KEY (UserReligionID) REFERENCES UserReligion(UserReligionID), FOREIGN KEY (ExpID) REFERENCES Expectations(ExpID)
);




CREATE TABLE Qualification ( QualificationID INT PRIMARY KEY,
 
QualificationType VARCHAR(30) NOT NULL
);
-- Inserting values into Qualification table
INSERT INTO Qualification (QualificationID, QualificationType) VALUES (1, 'Bachelors'),
(2, 'Masters'),
(3, 'PhD'),
(4, 'Associates Degree'),
(5, 'Diploma'),
(6, 'High School'),
(7, 'Certificate'),
(8, 'Postgraduate Diploma'),
(9, 'Doctorate'),
(10, 'MBA'),
(11, 'MD'),
(12, 'JD'),
(13, 'BSc'),
(14, 'MSc'),
(15, 'MPhil'),
(16, 'Engineering Degree'),
(17, 'Law Degree'),
(18, 'PharmD'),
(19, 'Bachelor of Arts'), (20, 'Bachelor of Science');
CREATE TABLE UserQualification (
 
UserQualificationID INT IDENTITY(1,1) PRIMARY KEY,
QualificationID INT NOT NULL,
University VARCHAR(35) NOT NULL, 
MajorCourse VARCHAR(30) NOT NULL, 
Profession VARCHAR(20) NOT NULL,

FOREIGN KEY (QualificationID) REFERENCES Qualification(QualificationID)
);


CREATE TABLE Job (
JobID INT PRIMARY KEY, --
JobName VARCHAR(30) NOT NULL -- doctor,engineer,lawyer,photographer etc
);
-- UserJob table
CREATE TABLE UserJob (
UserJobID INT IDENTITY(1,1) PRIMARY KEY,


JobID INT NOT NULL,
MonthlyIncome DECIMAL(10, 2) NOT NULL, FuturePlan VARCHAR(60) NOT NULL,

FOREIGN KEY (JobID) REFERENCES Job(JobID)
);


INSERT INTO Job (JobID, JobName) VALUES
 
(1, 'Doctor'),
(2, 'Engineer'),
(3, 'Lawyer'),
(4, 'Photographer'),
(5, 'Teacher'),
(6, 'Nurse'),
(7, 'Scientist'),
(8, 'Artist'),
(9, 'Software Developer'),
(10, 'Chef'),
(11, 'Musician'),
(12, 'Architect'),
(13, 'Plumber'),
(14, 'Carpenter'),
(15, 'Dentist'),
(16, 'Electrician'),
(17, 'Journalist'),
(18, 'Pilot'),
(19, 'Firefighter'),
(20, 'Therapist');
CREATE TABLE Appearance (
AppearanceID INT IDENTITY(1,1) PRIMARY KEY,


Disability VARCHAR(25) NOT NULL, Height DECIMAL(5, 2) NOT NULL,
 
Smoke VARCHAR(10) NOT NULL,
Complexion VARCHAR(20) NOT NULL, 
HairColor VARCHAR(20) NOT NULL,
Weight DECIMAL(5, 2) NOT NULL, 
Build VARCHAR(15) NOT NULL, 
EyeColor VARCHAR(15) NOT NULL,

);


CREATE TABLE [Messages] (
MessageID INT IDENTITY(1,1) PRIMARY KEY, 
SenderID INT NOT NULL,
ReceiverID INT NOT NULL,
MessageContent VARCHAR(MAX) NOT NULL, 
TimeSent DATETIME default getdate(),
foreign key (ReceiverID) REFERENCES [Candidate](candidateID),
foreign key (SenderID) REFERENCES [Candidate](candidateID)
);


CREATE TABLE UserImage (
ImageID INT IDENTITY(1,1) PRIMARY KEY,
PrivacyStatus VARCHAR(20) NOT NULL, Picture VARBINARY(MAX) NOT NULL,

);
 
CREATE TABLE Religion ( ReligionID INT PRIMARY KEY,
ReligionType VARCHAR(20) NOT NULL
);


INSERT INTO Religion (ReligionID, ReligionType) VALUES (1, 'Christianity'),
(2, 'Islam'),
(3, 'Hinduism'),
(4, 'Buddhism'),
(5, 'Judaism'),
(6, 'Sikhism'),
(7, 'Taoism'),
(8, 'Confucianism'),
(9, 'Shintoism'),
(10, 'Zoroastrianism'),
(11, 'Jainism'),
(12, 'Baháʼí Faith'),
(13, 'Paganism'),
(14, 'Atheism'),
(15, 'Agnosticism'),
(16, 'Deism'),
(17, 'Unitarianism'),
(18, 'Rastafari'),
 
(19, 'New Age'),
(20, 'Falun Gong');


CREATE TABLE UserReligion (
UserReligionID INT IDENTITY(1,1) PRIMARY KEY,


ReligionID INT NOT NULL,
KeepHalal VARCHAR(10) NOT NULL,
HijabPreference VARCHAR(10) NOT NULL, BeardPreference VARCHAR(10) NOT NULL, ConvertedReligion VARCHAR(5) NOT NULL, Sect VARCHAR(10) NOT NULL,
PerformSalah VARCHAR(10) NOT NULL,


FOREIGN KEY (ReligionID) REFERENCES Religion(ReligionID)
);
create table packages (
packageID INT PRIMARY KEY, 
Type varchar(20) not null,
Price decimal (10,2) not null, 
Duration_days int not null,
);


INSERT INTO packages (packageID, Type, Price, Duration_days) VALUES (1, 'Free', 0.00, 30),
 
(2, 'Gold', 10000.00, 45),
(3, 'Personalized', 50000.00, 60);


CREATE TABLE userPackages (
userPackageID INT IDENTITY(1,1) PRIMARY KEY,
packageID INT NOT NULL, 
startdate DATE NOT NULL, 
enddate DATE NOT NULL,
candidateid int not null,
Consultantid int,
constraint fk_cid foreign key(candidateid) references Candidate(CandidateID),


CONSTRAINT FK_Packagee_ID FOREIGN KEY (packageID) REFERENCES
packages(packageID),
constraint fk_consid foreign key (Consultantid) references Admin(Admin_ID)
);
CREATE TABLE Expectations (
ExpID INT IDENTITY(1,1) PRIMARY KEY,
agefrom int not null, ageto int not null,

Gender VARCHAR(10) NOT NULL, Country VARCHAR(20) NOT NULL,
MotherTongue VARCHAR(20) NOT NULL,
 
Sect VARCHAR(20) NOT NULL,
Profession VARCHAR(20) NOT NULL, 
MaritalStatus VARCHAR(20) NOT NULL,
Height DECIMAL(5, 2) NOT NULL,
Caste VARCHAR(20) NOT NULL, 
Religion VARCHAR(20) NOT NULL,
MonthlyIncome DECIMAL(10, 2) NOT NULL, 
Build VARCHAR(15) NOT NULL,
Disability VARCHAR(25) NOT NULL


);


CREATE VIEW UserProfileView AS SELECT
u.UserID, u.FirstName, u.LastName, u.City, u.Country,
u.isVerified, u.Gender, u.MaritalStatus, u.MotherTongue, u.Caste, u.DateOfBirth,
 
a.Disability, a.Height, a.Smoke, a.Complexion, a.HairColor, a.Weight, a.Build, a.EyeColor,
r.ReligionType AS Religion, ur.Sect,
ur.KeepHalal, ur.HijabPreference, ur.BeardPreference, ur.ConvertedReligion, q.QualificationType, uq.University, uq.MajorCourse,
uq.Profession AS QualificationProfession, j.JobName,
uj.MonthlyIncome, uj.FuturePlan,
ex.agefrom AS ExpectationAgeFrom, ex.ageto AS ExpectationAgeTo, ex.Gender AS ExpectationGender,
 
ex.Country AS ExpectationCountry, ex.MotherTongue AS ExpectationMotherTongue, ex.Sect AS ExpectationSect,
ex.Profession AS ExpectationProfession, ex.MaritalStatus AS ExpectationMaritalStatus, ex.Height AS ExpectationHeight,
ex.Caste AS ExpectationCaste, ex.Religion AS ExpectationReligion,
ex.MonthlyIncome AS ExpectationMonthlyIncome, ex.Build AS ExpectationBuild,
ex.Disability AS ExpectationDisability, ui.Picture AS ProfileImage,
ui.privacystatus
FROM
[User] u
JOIN Candidate c on u.UserID=c.UserID
JOIN
Appearance a ON c.AppearanceID = a.AppearanceID JOIN
UserReligion ur ON c.UserReligionID = ur.UserReligionID JOIN
Religion r ON ur.ReligionID = r.ReligionID JOIN
UserQualification uq ON c.UserQualificationID = uq.UserQualificationID JOIN
 
Qualification q ON uq.QualificationID = q.QualificationID JOIN
UserJob uj ON c.UserJobID = uj.UserJobID JOIN
Job j ON uj.JobID = j.JobID JOIN
Expectations ex ON c.ExpID = ex.ExpID JOIN
UserImage ui ON c.ImageID = ui.ImageID;


select * from UserProfileView
CREATE PROCEDURE AddAdminUser @City NVARCHAR(100),
@Email NVARCHAR(100),
@MotherTongue NVARCHAR(50), @MaritalStatus NVARCHAR(50), @Caste NVARCHAR(50),
@DateOfBirth DATE, @UserName NVARCHAR(50), @DateJoined DATE, @Country NVARCHAR(50), @FirstName NVARCHAR(50), @LastName NVARCHAR(50), @Phone NVARCHAR(20), @Gender NVARCHAR(10),
 @Pass NVARCHAR(100) AS
BEGIN


INSERT INTO [User] (City, Email, MotherTongue, MaritalStatus, Caste, DateOfBirth, UserName, DateJoined, Country, FirstName, LastName, Phone, Gender, UserType, Pass)
VALUES (@City, @Email, @MotherTongue, @MaritalStatus, @Caste, @DateOfBirth, @UserName, @DateJoined, @Country, @FirstName, @LastName, @Phone, @Gender, 'admin', @Pass);


SELECT 'Admin User Added Successfully' AS Message; 
END;

CREATE TRIGGER trg_AfterAdminUserInsert ON [User]
AFTER INSERT AS
BEGIN


IF EXISTS (SELECT 1 FROM inserted WHERE UserType = 'admin') BEGIN
INSERT INTO Admin (UserID) SELECT UserID
FROM inserted
WHERE UserType = 'admin'; END
 END;

CREATE TABLE UserLog (
LogID INT IDENTITY(1,1) PRIMARY KEY, UserID INT NOT NULL,
RegisteredAt DATETIME NOT NULL DEFAULT GETDATE(), LogDate DATE NOT NULL DEFAULT CAST(GETDATE() AS DATE), FOREIGN KEY (UserID) REFERENCES [User](UserID)
);


CREATE TRIGGER trg_InsertUserLog ON [User]
AFTER INSERT AS
BEGIN
INSERT INTO UserLog (UserID, RegisteredAt, LogDate) SELECT
UserID, GETDATE(),
CAST(GETDATE() AS DATE)
FROM inserted;
END;
CREATE PROCEDURE UpdateIsVerified 
@UserID INT,
@IsVerified VARCHAR(5) AS
 BEGIN
IF EXISTS ( SELECT 1 FROM [User]
WHERE UserID = @UserID AND UserType = 'candidate'
) BEGIN
UPDATE [User]
SET isVerified = @IsVerified WHERE UserID = @UserID;
PRINT 'isVerified has been updated successfully.'; END
ELSE BEGIN
PRINT 'User is not a candidate or does not exist.'; END
END;

CREATE FUNCTION CalculateAge ( @DateOfBirth DATE) RETURNS INT
AS BEGIN
DECLARE @Age INT;
 
SET @Age = DATEDIFF(YEAR, @DateOfBirth, GETDATE())
- CASE
WHEN MONTH(@DateOfBirth) > MONTH(GETDATE())
OR (MONTH(@DateOfBirth) = MONTH(GETDATE()) AND DAY(@DateOfBirth) > DAY(GETDATE()))
THEN 1
ELSE 0 END;

RETURN @Age; END;
SELECT UserID, FirstName, LastName, dbo.CalculateAge(DateOfBirth) AS Age FROM [User];

CREATE TABLE User_VerificationLog (
LogID INT IDENTITY(1,1) PRIMARY KEY, UserID INT NOT NULL,

OldStatus VARCHAR(5), NewStatus VARCHAR(5),
ChangeDate DATETIME DEFAULT GETDATE()
);

CREATE TRIGGER trg_IsVerifiedChange
 
ON [User] AFTER UPDATE AS
BEGIN
SET NOCOUNT ON;
INSERT INTO User_VerificationLog (UserID, OldStatus, NewStatus, ChangeDate) SELECT
INSERTED.UserID,
DELETED.isVerified AS OldStatus, INSERTED.isVerified AS NewStatus, GETDATE() AS ChangeDate
FROM
INSERTED INNER JOIN
DELETED ON INSERTED.UserID = DELETED.UserID WHERE
INSERTED.isVerified = 'Yes' AND DELETED.isVerified <> 'Yes'; 
END;

CREATE PROCEDURE UpdateAdminInfo @UserID INT,
@City VARCHAR(20), @Email VARCHAR(50), @Phone VARCHAR(11),
 @FirstName VARCHAR(30), @LastName VARCHAR(30)
AS BEGIN
IF EXISTS ( SELECT 1 FROM [User]
WHERE UserID = @UserID AND UserType = 'admin'
) BEGIN
UPDATE [User] SET
City = @City, Email = @Email, Phone = @Phone,
FirstName = @FirstName, LastName = @LastName
WHERE
UserID = @UserID;
PRINT 'Admin information updated successfully.'; END
ELSE
 BEGIN
PRINT 'You are not authorized to update this information.'; END
END;

CREATE PROCEDURE InsertUserPackage
    @PackageID INT,
    @StartDate DATE,
    @EndDate DATE,
    @CandidateID INT,
    @ConsultantID INT
AS
BEGIN
    INSERT INTO userPackages (packageID, startdate, enddate, candidateid, Consultantid)
    VALUES (@PackageID, @StartDate, @EndDate, @CandidateID, @ConsultantID);
END;



CREATE FUNCTION GetProfilesByJob (
@JobName VARCHAR(30) -- Job name to filter profiles
)
RETURNS TABLE AS
RETURN (
SELECT
UserID, FirstName, LastName, City, Country, Gender, MaritalStatus,
MotherTongue, Caste, Religion,
 
QualificationType, JobName, MonthlyIncome, FuturePlan, ProfileImage, privacystatus
FROM
UserProfileView WHERE
JobName = @JobName AND isVerified = 'Yes'
);




CREATE FUNCTION GetProfilesByReligionAndSect (
@ReligionType VARCHAR(20), @Sect VARCHAR(20)
)
RETURNS TABLE AS
RETURN (
SELECT
UserID,
 
FirstName, LastName, City, Country, Gender, MaritalStatus,
MotherTongue, Caste, Religion,
Sect, QualificationType, JobName, MonthlyIncome, FuturePlan, ProfileImage, privacystatus
FROM
UserProfileView WHERE
Religion = @ReligionType AND Sect = @Sect

);
CREATE FUNCTION GetProfilesByCountryAndCity (
 
@Country VARCHAR(20), @City VARCHAR(20)
)
RETURNS TABLE AS
RETURN (
SELECT
UserID, FirstName, LastName, City, Country, Gender, MaritalStatus,
MotherTongue, Caste, Religion,
QualificationType, JobName, MonthlyIncome, FuturePlan, ProfileImage, privacystatus
FROM
 
UserProfileView WHERE
Country = @Country AND City = @City

);


CREATE FUNCTION GetVerifiedProfiles() RETURNS TABLE
AS RETURN (
SELECT
UserID, FirstName, LastName, City, Country, Gender, MaritalStatus,
MotherTongue, Caste, Religion,
QualificationType, JobName,
 
MonthlyIncome, FuturePlan, ProfileImage, privacystatus
FROM
UserProfileView WHERE
isVerified = 'Yes'
);

CREATE FUNCTION GetProfilesByAge ( @AgeFrom INT,
@AgeTo INT
)
RETURNS TABLE AS
RETURN (
SELECT *
FROM UserProfileView
WHERE dbo.CalculateAge(DateOfBirth) BETWEEN @AgeFrom AND @AgeTo
 
);


CREATE PROCEDURE GetProfilesByMonthlyIncome 
    @MinIncome DECIMAL(10, 2), 
    @MaxIncome DECIMAL(10, 2)
AS
BEGIN
    SELECT
        *
    FROM
        UserProfileView upv
    WHERE
        upv.MonthlyIncome BETWEEN @MinIncome AND @MaxIncome
    ORDER BY
        upv.MonthlyIncome; 
END;
CREATE FUNCTION GetProfilesByDifferentCountry (@UserID INT)
RETURNS TABLE
AS
RETURN
(
    SELECT 
     *
    FROM 
        UserProfileView upv
    WHERE 
        upv.Country != (SELECT Country FROM [User] WHERE UserID = @UserID) 
);

CREATE PROCEDURE SearchProfilesByGender
    @Gender VARCHAR(10)
AS
BEGIN
    SELECT 
        *
    FROM 
        UserProfileView upv
    WHERE 
        upv.Gender = @Gender
    ORDER BY 
        upv.UserID;  
END;
CREATE PROCEDURE InsertMessage
    @SenderID INT,
    @ReceiverID INT,
    @MessageContent VARCHAR(MAX)
AS
BEGIN
    INSERT INTO [Messages] (SenderID, ReceiverID, MessageContent, TimeSent)
    VALUES (@SenderID, @ReceiverID, @MessageContent, GETDATE());
END;
CREATE FUNCTION GetProfilesBasedOnExpectations(@UserID INT)
RETURNS TABLE
AS
RETURN
(
    SELECT 
        upv.UserID,
        upv.FirstName,
        upv.LastName,
        upv.City,
        upv.Country,
        upv.isVerified,
        upv.Gender AS ProfileGender,
        upv.MaritalStatus,
        upv.MotherTongue,
        upv.Caste,
        upv.DateOfBirth,
        upv.ProfileImage,
        upv.privacystatus,
        ex.Gender AS ExpectedGender,
        ex.Country AS ExpectedCountry,
        ex.MotherTongue AS ExpectedMotherTongue,
        ex.MaritalStatus AS ExpectedMaritalStatus
    FROM UserProfileView upv
    JOIN Expectations ex ON ex.ExpID = (SELECT ExpID FROM Candidate WHERE UserID = @UserID)
    WHERE 
        upv.Gender = ex.Gender
        AND upv.Country = ex.Country
        AND upv.MotherTongue = ex.MotherTongue
        AND upv.MaritalStatus = ex.MaritalStatus
);

CREATE FUNCTION GetProfilesByMaritalStatus(@MaritalStatus VARCHAR(20))
RETURNS TABLE
AS
RETURN
(
    SELECT 
        upv.UserID,
        upv.FirstName,
        upv.LastName,
        upv.City,
        upv.Country,
        upv.isVerified,
        upv.Gender AS ProfileGender,
        upv.MaritalStatus,
        upv.MotherTongue,
        upv.Caste,
        upv.DateOfBirth,
        upv.ProfileImage,
        upv.privacystatus
    FROM UserProfileView upv
    WHERE 
        upv.MaritalStatus = @MaritalStatus
);

CREATE FUNCTION GetProfilesByUsername(@UserName VARCHAR(50))
RETURNS TABLE
AS
RETURN
(
    SELECT 
        upv.UserID,
        upv.FirstName,
        upv.LastName,
        upv.City,
        upv.Country,
        upv.isVerified,
        upv.Gender AS ProfileGender,
        upv.MaritalStatus,
        upv.MotherTongue,
        upv.Caste,
        upv.DateOfBirth,
        upv.Disability,
        upv.Height,
        upv.Smoke,
        upv.Complexion,
        upv.HairColor,
        upv.Weight,
        upv.Build,
        upv.EyeColor,
        upv.Religion,
        upv.Sect,
        upv.KeepHalal,
        upv.HijabPreference,
        upv.BeardPreference,
        upv.ConvertedReligion,
        upv.QualificationType,
        upv.University,
        upv.MajorCourse,
        upv.QualificationProfession,
        upv.JobName,
        upv.MonthlyIncome,
        upv.FuturePlan,
        upv.ExpectationAgeFrom,
        upv.ExpectationAgeTo,
        upv.ExpectationGender,
        upv.ExpectationCountry,
        upv.ExpectationMotherTongue,
        upv.ExpectationSect,
        upv.ExpectationProfession,
        upv.ExpectationMaritalStatus,
        upv.ExpectationHeight,
        upv.ExpectationCaste,
        upv.ExpectationReligion,
        upv.ExpectationMonthlyIncome,
        upv.ExpectationBuild,
        upv.ExpectationDisability,
        upv.ProfileImage,
        upv.privacystatus
    FROM UserProfileView upv
    JOIN [User] u ON u.UserID = upv.UserID
    WHERE u.UserName = @UserName
);
CREATE FUNCTION GetCandidateDetailsForAdmin(@CandidateUserID INT)
RETURNS TABLE
AS
RETURN
(
    SELECT 
        u.UserID,
        u.FirstName,
        u.LastName,
        u.City,
        u.Country,
        u.Email,
        u.Phone,
        u.MaritalStatus,
        u.Gender,
        u.MotherTongue,
        u.Caste,
        u.DateOfBirth,
        a.Disability,
        a.Height,
        a.Smoke,
        a.Complexion,
        a.HairColor,
        a.Weight,
        a.Build,
        a.EyeColor,
        r.ReligionType AS Religion,
        ur.Sect,
        ur.KeepHalal,
        ur.HijabPreference,
        ur.BeardPreference,
        ur.ConvertedReligion,
        q.QualificationType,
        uq.University,
        uq.MajorCourse,
        uq.Profession AS QualificationProfession,
        j.JobName,
        uj.MonthlyIncome,
        uj.FuturePlan,
        ex.agefrom AS ExpectationAgeFrom,
        ex.ageto AS ExpectationAgeTo,
        ex.Gender AS ExpectationGender,
        ex.Country AS ExpectationCountry,
        ex.MotherTongue AS ExpectationMotherTongue,
        ex.Sect AS ExpectationSect,
        ex.Profession AS ExpectationProfession,
        ex.MaritalStatus AS ExpectationMaritalStatus,
        ex.Height AS ExpectationHeight,
        ex.Caste AS ExpectationCaste,
        ex.Religion AS ExpectationReligion,
        ex.MonthlyIncome AS ExpectationMonthlyIncome,
        ex.Build AS ExpectationBuild,
        ex.Disability AS ExpectationDisability,
        ui.Picture AS ProfileImage,
        ui.privacystatus
    FROM 
        UserProfileView upv
    JOIN [User] u ON u.UserID = upv.UserID
    JOIN Candidate c ON u.UserID = c.UserID
    LEFT JOIN Appearance a ON c.AppearanceID = a.AppearanceID
    LEFT JOIN UserReligion ur ON c.UserReligionID = ur.UserReligionID
    LEFT JOIN Religion r ON ur.ReligionID = r.ReligionID
    LEFT JOIN UserQualification uq ON c.UserQualificationID = uq.UserQualificationID
    LEFT JOIN Qualification q ON uq.QualificationID = q.QualificationID
    LEFT JOIN UserJob uj ON c.UserJobID = uj.UserJobID
    LEFT JOIN Job j ON uj.JobID = j.JobID
    LEFT JOIN Expectations ex ON c.ExpID = ex.ExpID
    LEFT JOIN UserImage ui ON c.ImageID = ui.ImageID
    WHERE u.UserID = @CandidateUserID
);

